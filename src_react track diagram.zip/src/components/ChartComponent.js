import React from 'react';
import { Line, Bar } from 'react-chartjs-2';

class ChartComponent extends React.Component {
  render() {
    // Extracted data from your JSON
    const simulationTimeData = /* ... */; // Array of simulation times
    const simulationDistanceData = /* ... */; // Array of simulation distances
    const simulationSpeedData = /* ... */; // Array of simulation speeds

    // Chart data objects
    const lineChartData = {
      labels: simulationTimeData,
      datasets: [
        {
          label: 'Simulation Speed',
          data: simulationSpeedData,
          fill: true,
          backgroundColor: 'rgba(75,192,192,0.2)',
          borderColor: 'rgba(75,192,192,1)',
          borderWidth: 1,
        },
      ],
    };

    const areaChartData = {
      labels: simulationTimeData,
      datasets: [
        {
          label: 'Simulation Distance',
          data: simulationDistanceData,
          backgroundColor: 'rgba(75,192,192,0.2)',
          borderColor: 'rgba(75,192,192,1)',
          borderWidth: 1,
        },
      ],
    };

    return (
      <div>
        <h2>Line Chart</h2>
        <Line data={lineChartData} />

        <h2>Area Chart</h2>
        <Bar data={areaChartData} />
      </div>
    );
  }
}

export default ChartComponent;
