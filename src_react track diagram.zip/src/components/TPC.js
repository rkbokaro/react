/* eslint-disable no-const-assign */
/* eslint-disable no-unused-vars */




         const gravity = 9.81;
        export  function brakingDistance(CurrentSpeed, CurrentSpeedUnit, TargetSpeed, TargetSpeedUnit, DecelerationMPSS) {
            if (CurrentSpeedUnit === "KMPH") {
                CurrentSpeed = CurrentSpeed / 3.6;
            }
            if (TargetSpeedUnit === "KMPH") {
                TargetSpeed = TargetSpeed / 3.6;
            }
            
            let StopDistance = 0;
        
            let BrakingTime = (CurrentSpeed - TargetSpeed) / DecelerationMPSS;
        
            StopDistance = Math.ceil((CurrentSpeed + TargetSpeed) * 0.5 * BrakingTime);
        
          return StopDistance;
          
        }
        export  function ResistanceCurve(CurveAngle, TrainMass) {
            let Resistance = 0;
            if (CurveAngle !== 0) {
                Resistance = 0.4 * CurveAngle;
            }
            return Resistance * gravity * TrainMass * 0.001;
        }
        
        export  function ResistanceGradient(Grade, TrainMass) {
            let Resistance = 0;
            if (Grade !== 0) {
                Resistance = 1 / Grade;
            }
            return Resistance * gravity * TrainMass * 0.001;
}
        





        export  function TractiveEffort(Speed, SpeedUnit, Loco, NumberOfLoco) {
            let TE = 0;
            let type = "Standard";
        
            if (SpeedUnit === "MPS") {
                Speed *= 3.6;
            }
        
            if (Loco === "WAG-9") {
                if (type === "Standard") {
                    if (Speed >= 0 && Speed <= 15)
                        TE = 460;
                    else if (Speed > 15 && Speed <= 36)
                        TE = (-0.476) * Speed + 467.14;
                    else if (Speed > 36 && Speed <= 100)
                        TE = 4500 * 3.6 / Speed;
                    else if (Speed > 100 && Speed <= 110)
                        TE = 162 - (162 * (Speed - 100) / (110 - 100));
                    else
                        TE = 0;
                }
                else if (type === "Board") {
                    if (Speed >= 0 && Speed < 10)
                        TE = 460 - Speed * (460 - 325) / 10.0;
                    else if (Speed >= 10 && Speed < 49.84)
                        TE = 325.0;
                    else if (Speed > 36 && Speed <= 100)
                        TE = 4500 * 3.6 / Speed;
                    else if (Speed > 100 && Speed <= 110)
                        TE = 162 - (162 * (Speed - 100) / (110 - 100));
                    else
                        TE = 0;
                }
            }
            else if (Loco === "WAG-7") {
                if (type === "Standard") {
                    if (0 <= Speed && Speed < 21.39)
                        TE = 322.558;
                    else if (21.39 <= Speed && Speed < 51.33)
                        TE = -0.233 * Speed + 327.529;
                    else if (51.33 <= Speed && Speed < 140)
                        TE = 4500 * 3.6 / Speed;
                    else if (140 <= Speed && Speed < 150)
                        TE = -11.571 * Speed + 1735.71;
                    else
                        TE = 0;
                }
            }
            else if (Loco === "WAG-5") {
                if (type === "Standard") {
                    if (0 <= Speed && Speed < 48)
                        TE = 194.17167;
                    else if (48 <= Speed && Speed < 80)
                        TE = 2588 * 3.6 / Speed;
                    else if (80 <= Speed && Speed < 100)
                        TE = -5.825 * Speed + 582.5;
                    else
                        TE = 0;
                }
            }
            if (Loco === "WAP-7") {
                if (type === "Standard") {
                  if (0 <= Speed && Speed < 21.39)
                    TE = 322.558;
                  else if (21.39 <= Speed && Speed < 51.33)
                    TE = -0.233 * Speed + 327.529;
                  else if (51.33 <= Speed && Speed < 140)
                    TE = 4500 * 3.6 / Speed;
                  else if (140 <= Speed && Speed < 150)
                    TE = -11.571 * Speed + 1735.71;
                  else
                    TE = 0;
                }
                else if (type === "Lower") {
                  if (0 <= Speed && Speed < 64.8)
                    TE = 250.0;
                  else if (64.8 <= Speed && Speed < 140)
                    TE = 4500 * 3.6 / Speed;
                  else if (140 <= Speed && Speed < 150)
                    TE = -11.57 * Speed + 1735.714;
                  else
                    TE = 0;
                }
                else if (type === "Heigher") {
                  if (0 <= Speed && Speed < 19.55)
                    TE = 352.81;
                  else if (19.55 <= Speed && Speed < 46.9)
                    TE = -0.28 * Speed + 358.275;
                  else if (46.9 <= Speed && Speed < 140)
                    TE = 4500 * 3.6 / Speed;
                  else if (140 <= Speed && Speed < 150)
                    TE = -11.57 * Speed + 1735.714;
                  else
                    TE = 0;
                }
                else if (type === "Advanced") {
                  if (0 <= Speed && Speed < 19.55)
                    TE = 352.81;
                  else if (19.55 <= Speed && Speed < 46.94)
                    TE = -0.28 * Speed + 358.273;
                  else if (46.94 <= Speed && Speed < 140)
                    TE = 4736 * 3.6 / Speed;
                  else if (140 <= Speed && Speed < 150)
                    TE = -12.178 * Speed + 1826.743;
                  else
                    TE = 0;
                }
                else if (type === "Board") {
                  if (0 <= Speed && Speed < 10)
                    TE = 322.558 - Speed * (322.558 - 228) / 10.0;
                  else if (10.0 <= Speed && Speed < 71.05)
                    TE = 228.0;
                  else if (71.05 <= Speed && Speed < 140)
                    TE = 4500 * 3.6 / Speed;
                  else if (140 <= Speed && Speed < 150)
                    TE = -11.571 * Speed + 1735.71;
                  else
                    TE = 0;
                }
              }
            }
              
              
              
              
            // export  function TractiveEffort(Speed, Loco, NumberOfLoco) {
            //     let TE = 0;
                
            //     if (Loco === "DESIRO") {
            //         if (0 <= Speed && Speed < 80)
            //             TE = 782;
            //         else if (80 <= Speed && Speed < 160)
            //             TE = 17378 * 3.6 / Speed;
            //         else if (160 <= Speed && Speed < 178)
            //             TE = 391.05 - (391.05 * (Speed - 160) / (178 - 160));
            //         else
            //             TE = 0;
            //     }
            //     else if (Loco === "VNDB") {
            //         if (0 <= Speed && Speed < 41.5)
            //             TE = 800;
            //         else if (41.5 <= Speed && Speed < 160)
            //             TE = 9222.3 * 3.6 / Speed;
            //         else if (160 <= Speed && Speed < 180)
            //             TE = 207.50 - (207.50 * (Speed - 160) / (180 - 160));
            //         else
            //             TE = 0;
            //     }
            //     else if (Loco === "WAP-5") {
            //         if (type === "Standard") {
            //             if (0 <= Speed && Speed < 30)
            //                 TE = 258;
            //             else if (30 <= Speed && Speed < 65)
            //                 TE = -1.029 * Speed + 288.857;
            //             else if (65 <= Speed && Speed < 160)
            //                 TE = 4000 * 3.6 / Speed;
            //             else if (160 <= Speed && Speed < 178)
            //                 TE = -5.0 * Speed + 890;
            //             else
            //                 TE = 0;
            //         }
            //         else if (type === "Board") {
            //             if (0 <= Speed && Speed < 10)
            //                 TE = 258 - Speed * (258 - 220) / 10.0;
            //             else if (10 <= Speed && Speed < 65.45)
            //                 TE = 220;
            //             else if (65.45 <= Speed && Speed < 160)
            //                 TE = 4000 * 3.6 / Speed;
            //             else if (160 <= Speed && Speed < 178)
            //                 TE = -5.0 * Speed + 890;
            //             else
            //                 TE = 0;
            //         }
            //     }
            //     else if (Loco === "WAP-4") {
            //         if (type === "Standard") {
            //             if (0 <= Speed && Speed < 72)
            //                 TE = 186;
            //             else if (72 <= Speed && Speed < 120)
            //                 TE = 3720 * 3.6 / Speed;
            //             else if (120 <= Speed && Speed < 130)
            //                 TE = -11.16 * Speed + 1450.8;
            //             else
            //                 TE = 0;
            //         }
            //         else if (type === "Board") {
            //             if (0 <= Speed && Speed < 10)
            //                 TE = 186 - Speed * (258 - 220) / 10.0;
            //             else if (10 <= Speed && Speed < 65.45)
            //                 TE = 220;
            //             else if (65.45 <= Speed && Speed < 160)
            //                 TE = 4000 * 3.6 / Speed;
            //             else if (160 <= Speed && Speed < 178)
            //                 TE = -5.0 * Speed + 890;
            //             else
            //                 TE = 0;
            //         }
            //     }
            
            //     return TE * NumberOfLoco;
            // }
            
              
               
        


        

       
            

          
            export  function BrakingEffort(Speed, SpeedUnit, Loco, NumberOfLoco) {
                let BE = 0;
                let BrakingTractiveRatio = -260.0 / 460.0;

            if (SpeedUnit == "MPS")
            {
                Speed = Speed * 3.6;
            }

            if (Loco == "WAG-9")
            {
                if (Speed >= 0 && Speed <= 10)
                {
                    BE = (-260.0 / 10.0) * Speed;
                }
                else if (Speed > 10 && Speed <= 15)
                {
                    BE = (BrakingTractiveRatio) * (460);
                }
                else if (Speed > 15 && Speed <= 36)
                {
                    BE = (BrakingTractiveRatio) * (((-0.476) * Speed) + 467.14);
                }
                else if (Speed > 36)
                {
                    BE = (BrakingTractiveRatio) * (4500 * 3.6 / Speed);
                }
                else
                {
                    BE = 0;
                }
            }
            return BE * NumberOfLoco;
        }




        export  function ResistanceLoco(Speed, SpeedUnit, Loco, NumberOfLoco) {
            let NoOfAaxels;
            let AdhesiveMass = 0;
            let Resistance = 0;
            const StartingResistance = 6.0;
            const ResistanceAtRollingSpeed = 0;
            const RollingSpeedKMPH = 3.6;
          
            if (SpeedUnit === "MPS") {
              Speed = Speed * 3.6;
            }
          
            if (Loco === "WAG-5") {
              NoOfAaxels = 6;
              AdhesiveMass = 119.0;
              if (Speed <= RollingSpeedKMPH) {
                ResistanceAtRollingSpeed =
                  (0.057 / AdhesiveMass) * RollingSpeedKMPH * RollingSpeedKMPH +
                  0.00933 * RollingSpeedKMPH +
                  (0.647 + (13.17 * NoOfAaxels) / AdhesiveMass);
                Resistance =
                  StartingResistance +
                  ((ResistanceAtRollingSpeed - StartingResistance) /
                    RollingSpeedKMPH) *
                    Speed;
              } else {
                Resistance =
                  (0.057 / AdhesiveMass) * Speed * Speed +
                  0.00933 * Speed +
                  (0.647 + (13.17 * NoOfAaxels) / AdhesiveMass);
              }
            } else if (Loco === "WAG-7") {
              NoOfAaxels = 6;
              AdhesiveMass = 123.0;
              if (Speed <= RollingSpeedKMPH) {
                ResistanceAtRollingSpeed =
                  (0.057 / AdhesiveMass) * RollingSpeedKMPH * RollingSpeedKMPH +
                  0.00933 * RollingSpeedKMPH +
                  (0.647 + (13.17 * NoOfAaxels) / AdhesiveMass);
                Resistance =
                  StartingResistance +
                  ((ResistanceAtRollingSpeed - StartingResistance) /
                    RollingSpeedKMPH) *
                    Speed;
              } else {
                Resistance =
                  (0.057 / AdhesiveMass) * Speed * Speed +
                  0.00933 * Speed +
                  (0.647 + (13.17 * NoOfAaxels) / AdhesiveMass);
              }
            } else if (Loco === "WAG-9") {
              NoOfAaxels = 6;
              AdhesiveMass = 123.0;
              if (Speed <= RollingSpeedKMPH) {
                ResistanceAtRollingSpeed =
                  (0.057 / AdhesiveMass) * RollingSpeedKMPH * RollingSpeedKMPH +
                  0.00933 * RollingSpeedKMPH +
                  (0.647 + (13.17 * NoOfAaxels) / AdhesiveMass);
                Resistance =
                  StartingResistance +
                  ((ResistanceAtRollingSpeed - StartingResistance) /
                    RollingSpeedKMPH) *
                    Speed;
              } else {
                Resistance =
                  (0.057 / AdhesiveMass) * Speed * Speed +
                  0.00933 * Speed +
                  (0.647 + (13.17 * NoOfAaxels) / AdhesiveMass);
              }
            } else if (Loco == "WAP-7")
            {
                NoOfAaxels = 6;
                AdhesiveMass = 123.0;

                if (Speed <= RollingSpeedKMPH)
                {
                    ResistanceAtRollingSpeed = (0.057 / AdhesiveMass) * RollingSpeedKMPH * RollingSpeedKMPH + 0.00933 * RollingSpeedKMPH + (0.647 + (13.17 * NoOfAaxels) / AdhesiveMass);
                    Resistance = StartingResistance + ((ResistanceAtRollingSpeed - StartingResistance) / (RollingSpeedKMPH)) * Speed;
                }
                else
                {
                    Resistance = (0.057 / AdhesiveMass) * Speed * Speed + 0.00933 * Speed + (0.647 + (13.17 * NoOfAaxels) / AdhesiveMass);
                }
            }
            else if (Loco == "WAP-5")
            {
                NoOfAaxels = 4;
                AdhesiveMass = 78.0;
                if (Speed <= RollingSpeedKMPH)
                {
                    ResistanceAtRollingSpeed = (0.057 / AdhesiveMass) * RollingSpeedKMPH * RollingSpeedKMPH + 0.00933 * RollingSpeedKMPH + (0.647 + (13.17 * NoOfAaxels) / AdhesiveMass);
                    Resistance = StartingResistance + ((ResistanceAtRollingSpeed - StartingResistance) / (RollingSpeedKMPH)) * Speed;
                }
                else
                {
                    Resistance = (0.057 / AdhesiveMass) * Speed * Speed + 0.00933 * Speed + (0.647 + (13.17 * NoOfAaxels) / AdhesiveMass);
                }
            }
           
            else if (Loco == "DESIRO")
            {
                NoOfAaxels = 20;
                AdhesiveMass = 966.0;
               
                Resistance = ((6.5666 / (3.6 * 3.6)) * Speed * Speed) + ((51.46 / 3.6) * Speed) + (0.0162 * AdhesiveMass * 1000.0);
                //}
                return Resistance * NumberOfLoco * 0.001;
            }
            else if (Loco == "VNDB")
            {
                NoOfAaxels = 20;
                AdhesiveMass = 966.0;
              
                Resistance = ((6.5666 / (3.6 * 3.6)) * Speed * Speed) + ((51.46 / 3.6) * Speed) + (0.0162 * AdhesiveMass * 1000.0);
                //}
                return Resistance * NumberOfLoco * 0.001;
            }

            return Resistance * NumberOfLoco * AdhesiveMass * 0.001;
        }
          


        
       
        export  function ResistanceCoach(Speed, SpeedUnit, Type, TrailingLoad) {

          alert("hello tpc");
          alert(Speed);
            let Resistance = 0;
            const StartingResistance = 5.0;
            const ResistanceAtRollingSpeed = 0;
            const RollingSpeedKMPH = 3.0;

            if (SpeedUnit == "MPS")
            {
                Speed = Speed * 3.6;
            }

            if (Type == "COACH")
            {
                if (Speed <= RollingSpeedKMPH)
                {
                    ResistanceAtRollingSpeed = 0.000082 * RollingSpeedKMPH * RollingSpeedKMPH + 0.02112 * RollingSpeedKMPH + 0.6855;
                    Resistance = StartingResistance + ((ResistanceAtRollingSpeed - StartingResistance) / (RollingSpeedKMPH)) * Speed;
                }
                else
                {
                    Resistance = 0.000082 * Speed * Speed + 0.02112 * Speed + 0.6855;
                }
            }
            return Resistance * gravity * TrailingLoad * 0.001;
        }
        export  function ResistanceWagon(Speed, SpeedUnit, Type, TrailingLoad) {
            let Resistance = 0;
            const StartingResistance = 4.0;
            const ResistanceAtRollingSpeed = 0;
            const RollingSpeedKMPH = 3.0;
          

            if (SpeedUnit == "MPS")
            {
                Speed = Speed * 3.6;
            }

            if (Type == "WAGON")
            {
                if (Speed <= RollingSpeedKMPH)
                {
                    ResistanceAtRollingSpeed = 0.000056 * RollingSpeedKMPH * RollingSpeedKMPH + 0.0103 * RollingSpeedKMPH + 0.87;
                    Resistance = StartingResistance + ((ResistanceAtRollingSpeed - StartingResistance) / (RollingSpeedKMPH)) * Speed;
                }
                else
                {
                    Resistance = 0.000056 * Speed * Speed + 0.0103 * Speed + 0.87;
                }
            }
            return Resistance * gravity * TrailingLoad * 0.001;
        }
        export  function ResistanceTrain(
            Loco,
            NumberOfLoco,
            AdhesiveMass,
            TrailingLoad,
            TrailType,
            Speed,
            SpeedUnit,
            CurveAngle,
            GradeValue
          ) {
            let Resistance = 0;

            Resistance = ResistanceLoco(Speed,SpeedUnit, Loco, NumberOfLoco)
                         + (TrailType == "COACH" ? ResistanceCoach(Speed, SpeedUnit, "COACH", TrailingLoad) : ResistanceWagon(Speed, SpeedUnit, "WAGON", TrailingLoad))
                         + ResistanceCurve(CurveAngle, NumberOfLoco * AdhesiveMass + TrailingLoad)
                         + ResistanceGradient(GradeValue, NumberOfLoco * AdhesiveMass + TrailingLoad);
            return Resistance;
        }

        class Loco {
            constructor(name, value1, value2) {
                this.Name = name;
                this.Value1 = value1;
                this.Value2 = value2;
            }
        }
        
        class Stock {
            constructor(type, name, value1, value2, value3) {
                this.Type = type;
                this.Name = name;
                this.Value1 = value1;
                this.Value2 = value2;
                this.Value3 = value3;
            }
        }
        
        let LocoList = [];
        let StockList = [];
        
        export  function PopulateLocoList() {
            LocoList.push(new Loco("VNDB", 78, 25));
            LocoList.push(new Loco("WAP-4", 113, 19));
            LocoList.push(new Loco("WAP-5", 78, 18));
            LocoList.push(new Loco("WAP-7", 123, 20));
            LocoList.push(new Loco("WAG-5", 119, 17));
            LocoList.push(new Loco("WAG-7", 123, 21));
            LocoList.push(new Loco("WAG-9", 123, 20));
            LocoList.push(new Loco("EMU", 0, 0));
            LocoList.push(new Loco("4KHP100", 123, 20));
            LocoList.push(new Loco("5KHP100", 123, 20));
            LocoList.push(new Loco("6KHP100", 123, 20));
        }
        
        export  function PopulateStockList() {
            StockList.push(new Stock("COACH", "VNDB", 43, 48, 22));
            StockList.push(new Stock("COACH", "LHB", 43, 48, 24));
            StockList.push(new Stock("COACH", "ICF", 45, 50, 22));
            StockList.push(new Stock("COACH", "HYBRID", 43, 48, 24));
            StockList.push(new Stock("WAGON", "EMU", 15, 20, 22));
            StockList.push(new Stock("WAGON", "BCN", 20, 92, 15));
            StockList.push(new Stock("WAGON", "BOXN", 20, 92, 10));
            StockList.push(new Stock("WAGON", "CONTAINER", 5, 27, 12));
        }
        
      

    