/* eslint-disable no-unused-vars */
// import TPC from './components/TPC';

import { ResistanceCoach, ResistanceWagon } from './TPC';

export function SimulateWithParameter() {
   alert("hello111");
   let aa = "kk";
   let bb = "kk";
   let cc = "kk";
   let dd = "kk";
   ResistanceCoach(aa,bb,cc,dd);
   alert("hello111");
}


//const LineColour = ["blue", "red", "green", "cyan", "pink", "purple", "brown", "magenta", "orange", "violet"];

// function SimulateWithParameter(LocoType, NumberOfLoco, AdhesiveMass, TrailType, TrailingLoad, TrainLength) {
//    let IterationNumber = 0;
   
//    let AccelarationMPSS = 0.50;
//    let Second = 0;
//    let VelocityKMPH = 0;
//    let VelocityMPS = 0;
//    let NextVelocityMPS = 0;
//    let TargetSpeed = 0;
//    let Decelaration = 0.75 * NumberOfLoco;

//    if (LocoType === "VNDB") {
//        Decelaration = 0.75 * NumberOfLoco;
//    } else if (LocoType === "EMU" || LocoType === "MEMU") {
//        Decelaration = 0.5 * NumberOfLoco;
//    } else if (LocoType === "WAP7" || LocoType === "WAP5") {
//        Decelaration = 0.25 * NumberOfLoco;
//    } else {
//        Decelaration = 0.125;
//    }

//    let Simulated = false;
//    let VelocityLine = new Polyline();
//    VelocityLine.Stroke = LineColour[IterationNumber % 10];
//    VelocityLine.Effect = ds;
//    Graph.Children.Add(VelocityLine);
//    let DistanceLine = new Polyline();
//    DistanceLine.Stroke = LineColour[IterationNumber % 10];
//    DistanceLine.Effect = ds;
//    Graph.Children.Add(DistanceLine);
//    let DistanceSpeedLine = new Polyline();
//    DistanceSpeedLine.Stroke = LineColour[IterationNumber % 10];
//    DistanceSpeedLine.Effect = ds;
//    Graph.Children.Add(DistanceSpeedLine);
//    let Mode = "";
//    let PrevMode = "";
//    let Stoppage = 0;
//    let CoveredDistanceInMeter = 0;
//    let CoveredDistanceInKm = 0;
//    let BrakeStartPoint = Route.Count;
//    let TargetPoint = Route.Count;
//    let SpeedRestrictionFlag = false;
//    let PrevPosition = "";

//    CountACC = 0;
//    CountDCC = 0;
//    CountCoast = 0;
//    CountStop = 0;

//    let IsCoasting = false;

//    let TotalDCCTimeInSec = 0;
//    let TotalACCTimeInSec = 0;
//    let TotalSTPGTimeInSec = 0;
//    let TotalCOASTTimeInSec = 0;
//    let AverageSpeedMPS = 0;
//    let EnergyConsumedJule = 0;
//    IterationNumber++;
//    //txtSchedule.Text += DefaultMaxSpeed + "\t" + LocoType + "\t" + NumberOfLoco + "\t" + TrailingLoad + "\n";
//    while (true) {
//      SpeedRestrictionFlag = false;
//      if (Route[CoveredDistanceInMeter].Position !== "" && Route[CoveredDistanceInMeter].Position !== PrevPosition) {
//        txtSchedule.Text += DefaultMaxSpeed + "\t" + LocoType + "\t" + NumberOfLoco + "\t" + TrailingLoad + "\t" + Route[CoveredDistanceInMeter].Position
//          + "\t"
//          + CoveredDistanceInKm.toString().padStart(7, '0')
//          + "\t"
//          + Math.trunc(Second / 3600).toString().padStart(2, '0') + ":" + (Math.trunc(Second / 60) % 60).toString().padStart(2, '0') + ":" + Math.trunc(Second % 60).toString().padStart(2, '0')
//          + "\t"
//          + Math.trunc((Second + Route[CoveredDistanceInMeter].StoppageTime) / 3600).toString().padStart(2, '0') + ":" + (Math.trunc((Second + Route[CoveredDistanceInMeter].StoppageTime) / 60) % 60).toString().padStart(2, '0') + ":" + Math.trunc((Second + Route[CoveredDistanceInMeter].StoppageTime) % 60).toString().padStart(2, '0')
//          + "\n";
//        PrevPosition = Route[CoveredDistanceInMeter].Position;
//      }
   
//      for (let i = CoveredDistanceInMeter; i < Math.min(CoveredDistanceInMeter + TPC.BrakingDistance(VelocityMPS, "MPS", 0, "MPS", Decelaration), Route.length); i++) {
//        if (Route[i].EffectiveMaximumSpeed < (VelocityMPS * 3.6) || Route[i].StoppageFlag === true) {
//          if (Route[i].StoppageFlag === true) {
//            BrakeStartPoint = i - TPC.BrakingDistance(VelocityMPS, "MPS", 0, "KMPH", Decelaration);
//            TargetPoint = i;
//            TargetSpeed = 0;
//          } else if (BrakeStartPoint > i - TPC.BrakingDistance(VelocityMPS, "MPS", Route[i].EffectiveMaximumSpeed, "KMPH", Decelaration)) {
//            BrakeStartPoint = i - TPC.BrakingDistance(VelocityMPS, "MPS", Route[i].EffectiveMaximumSpeed, "KMPH", Decelaration);
//            TargetPoint = i;
//            TargetSpeed = Route[i].EffectiveMaximumSpeed / 3.6;
//          }
//        }
//      }
     
//      if (CoveredDistanceInMeter >= BrakeStartPoint - 1 && CoveredDistanceInMeter < TargetPoint) {
//        Mode = "DCC";
//      } else if (Route[CoveredDistanceInMeter].StoppageFlag === true && Stoppage <= Route[CoveredDistanceInMeter].StoppageTime) {
//        Mode = "STOP";
//      } else if (Stoppage === Route[CoveredDistanceInMeter].StoppageTime || CoveredDistanceInMeter === 0) {
//        Mode = "ACC";
//        BrakeStartPoint = Route.length;
//      } else if (SpeedRestrictionFlag === false) {
//       Mode = "ACC";
//       BrakeStartPoint = Route.Count;
//   }
//   else if (SpeedRestrictionFlag == true)
//   {
//       Mode = "DCC";
//       BrakeStartPoint = Route.Count;
//   }

//   if (!string.IsNullOrWhiteSpace(PrevMode) && PrevMode != Mode)
//   {
//       if (PrevMode == "ACC")
//           CountACC++;
//       if (PrevMode == "DCC")
//           CountDCC++;
//       if (PrevMode == "STOP")
//           CountStop++;
//   }

//   PrevMode = Mode;


//        if (Mode === "ACC") {
//          Stoppage = 0;
//          AccelarationMPSS = (TPC.TractiveEffort(VelocityMPS, "MPS", LocoType, NumberOfLoco) - TPC.ResistanceTrain(LocoType, NumberOfLoco, AdhesiveMass, TrailingLoad, TrailType, VelocityMPS, "MPS", Route[CoveredDistanceInMeter].EffectiveCurveAngle, Route[CoveredDistanceInMeter].EffectiveGradeValue)) / (AdhesiveMass * NumberOfLoco + TrailingLoad);
//          NextVelocityMPS = Math.min(Route[CoveredDistanceInMeter].EffectiveMaximumSpeed / 3.6, Math.sqrt((VelocityMPS * VelocityMPS) + (2 * AccelarationMPSS * UnitDistanceInMeter)));
       
//          if (AccelarationMPSS <= 0) {
       
//          }
       
//          if (VelocityMPS === Route[CoveredDistanceInMeter].EffectiveMaximumSpeed / 3.6 && IsCoasting === false) {
//            IsCoasting = true;
//            CountCoast++;
//          } else {
//            IsCoasting = false;
//          }
       
//          if (AccelarationMPSS > 0.0001) {
//            TotalACCTimeInSec += ((2 * UnitDistanceInMeter) / (VelocityMPS + NextVelocityMPS));
//          } else {
//            TotalCOASTTimeInSec += ((2 * UnitDistanceInMeter) / (VelocityMPS + NextVelocityMPS));
//          }
       
//          EnergyConsumedJule += TPC.TractiveEffort(VelocityMPS, "MPS", LocoType, NumberOfLoco) * UnitDistanceInMeter;
       
//          Second = Second + ((2 * UnitDistanceInMeter) / (VelocityMPS + NextVelocityMPS));
//          VelocityMPS = NextVelocityMPS;
//          CoveredDistanceInMeter += UnitDistanceInMeter;
//        }
       
//        if (Mode === "DCC") {
//          AccelarationMPSS = (-1.0) * Decelaration;
//          if (((VelocityMPS * VelocityMPS) + (2 * AccelarationMPSS * UnitDistanceInMeter)) > TargetSpeed * TargetSpeed) {
//            NextVelocityMPS = Math.sqrt((VelocityMPS * VelocityMPS) + (2 * AccelarationMPSS * UnitDistanceInMeter));
//          } else {
//            NextVelocityMPS = TargetSpeed;
//          }
//          TotalDCCTimeInSec += ((2 * UnitDistanceInMeter) / (VelocityMPS + NextVelocityMPS));
//          Second = Second + ((2 * UnitDistanceInMeter) / (VelocityMPS + NextVelocityMPS));
//          VelocityMPS = NextVelocityMPS;
//          CoveredDistanceInMeter += UnitDistanceInMeter;
//        }
       
//        if (Mode === "STOP" || CoveredDistanceInMeter === Route.length - 1) {
//          AccelarationMPSS = 0;
//          Second = Second + 1.0;
//          VelocityMPS = 0;
//          CoveredDistanceInMeter += 0;
//          Stoppage++;
//        }
       
//        if (Mode === "STOP") {
//          TotalSTPGTimeInSec++;
//        }
//        AverageSpeedMPS = CoveredDistanceInMeter / Second;

// AccelarationKMPHPS = AccelarationMPSS * 3.6;
// VelocityKMPH = VelocityMPS * 3.6;
// CoveredDistanceInKm = CoveredDistanceInMeter * 0.001;

// if (VelocityKMPH >= 125)
//   Count++;

// txtAccelaration.textContent = AccelarationKMPHPS.toFixed(3);
// txtSpeed.textContent = VelocityKMPH.toFixed(3);
// txtDistance.textContent = CoveredDistanceInKm.toFixed(3);

// txtACCCount.textContent = CountACC.toString();
// txtDCCCount.textContent = CountDCC.toString();
// txtSTPGCount.textContent = CountStop.toString();
// txtCOASTCount.textContent = CountCoast.toString();
// txtACCTime.textContent = Math.trunc(TotalACCTimeInSec / 3600).toString().padStart(2, '0') + ":" + (Math.trunc(TotalACCTimeInSec / 60) % 60).toString().padStart(2, '0') + ":" + Math.trunc(TotalACCTimeInSec % 60).toString().padStart(2, '0');
// txtDCCTime.textContent = Math.trunc(TotalDCCTimeInSec / 3600).toString().padStart(2, '0') + ":" + (Math.trunc(TotalDCCTimeInSec / 60) % 60).toString().padStart(2, '0') + ":" + Math.trunc(TotalDCCTimeInSec % 60).toString().padStart(2, '0');
// txtSTPGTime.textContent = Math.trunc(TotalSTPGTimeInSec / 3600).toString().padStart(2, '0') + ":" + (Math.trunc(TotalSTPGTimeInSec / 60) % 60).toString().padStart(2, '0') + ":" + Math.trunc(TotalSTPGTimeInSec % 60).toString().padStart(2, '0');
// txtCOASTTime.textContent = Math.trunc(TotalCOASTTimeInSec / 3600).toString().padStart(2, '0') + ":" + (Math.trunc(TotalCOASTTimeInSec / 60) % 60).toString().padStart(2, '0') + ":" + Math.trunc(TotalCOASTTimeInSec % 60).toString().padStart(2, '0');
// txtAvgSpeed.textContent = (AverageSpeedMPS * 3.6).toFixed(2);
// txtEnergyConsumed.textContent = (EnergyConsumedJule / 1000).toFixed(1);

// var Velocity = new Point();
// Velocity.X = Second * ScaleX;
// Velocity.Y = OffSetY - (VelocityKMPH * ScaleY);
// VelocityLine.Points.push(Velocity);

// var Distance = new Point();
// Distance.X = Second * ScaleX;
// Distance.Y = DistanceGraphOffSet - (CoveredDistanceInKm * DistanceScale);
// DistanceLine.Points.push(Distance);

// var DistanceSpeed = new Point();
// DistanceSpeed.X = CoveredDistanceInKm * DistanceSpeedScaleX;
// DistanceSpeed.Y = DistanceSpeedOffSet - (VelocityKMPH * DistanceSpeedScaleY);
// DistanceSpeedLine.Points.push(DistanceSpeed);

// txtTime.textContent = Math.trunc(Second / 3600).toString().padStart(2, '0') + ":" + (Math.trunc(Second / 60) % 60).toString().padStart(2, '0') + ":" + Math.trunc(Second % 60).

//       }}   