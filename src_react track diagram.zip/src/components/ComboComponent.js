import React, { Component } from 'react';

class ComboBox extends Component {
  constructor(props) {
    super(props);

    this.state = {
      selectedOption: 'Option 1'
    };
  }

  handleChange = (event) => {
    this.setState({ selectedOption: event.target.value });
  }

  render() {
    return (
      <div>
        <select value={this.state.selectedOption} onChange={this.handleChange}>
          <option value="Option 1">Option 1</option>
          <option value="Option 2">Option 2</option>
          <option value="Option 3">Option 3</option>
        </select>
        <br />
        <input type="text" value={this.state.selectedOption} />
      </div>
    );
  }
}

export default ComboBox;
