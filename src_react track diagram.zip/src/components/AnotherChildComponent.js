import React, { useContext } from 'react';
import MyContext from "../MyContext"; // Import the context from App.js

const AnotherChildComponent = () => {
  const { data } = useContext(MyContext); // Use the context

  return (
    <div>
      <h3>Another Child Component</h3>
      <p>Data from Context: {data}</p>
    </div>
  );
};

export default AnotherChildComponent;




