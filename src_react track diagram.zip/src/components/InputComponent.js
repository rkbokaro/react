/* eslint-disable react/prop-types */
/* eslint-disable no-unused-vars */
import React, { Component ,useRef} from 'react';



class Loco {
  constructor(loco, weight, length) {
    this.LocoType = loco;
    this.Weight = weight;
    this.Length = length;
  }
}

class Stock {
  constructor(trailType, stockType, emptyWeight, loadedWeight, length) {
      this.TrailType = trailType;
      this.StockType = stockType;
      this.EmptyWeight = emptyWeight;
      this.LoadedWeight = loadedWeight;
      this.Length = length;
  }
}


class LocoStock {
  constructor(stockType, stockcount, stockunitweight, stockunitlength, locotype, lococount, locounitweight, locounitlength, trailweight, traillength, locoweight, locolength, totalweight, totallength) {
      this.stockType = stockType;
      this.stockcount = stockcount;
      this.stockunitweight = stockunitweight;
      this.stockunitlength = stockunitlength;
      this.locotype = locotype;
      this.lococount = lococount;
      this.locounitweight = lococount;
      this.locounitlength = locounitweight;

      this.locounitlength = locounitlength;
      this.trailweight = trailweight;
      this.traillength = traillength;
      this.locoweight = locoweight;
      this.locolength = locolength;
      this.totalweight = totalweight;
      this.totallength = totallength;
      
    }
  }


class InputComponent extends Component {

 
   //comboBoxRef = useRef(null);
   SelectedStock1;


   sendDataToParent = () => {
    const data = 'Hello, Parent!';

    this.SelectedStock1 = new LocoStock();
   this.SelectedStock1.trailweight =this.TrailingLoadInTons;
   this.SelectedStock1.traillength =this.TrainLength;

   this.SelectedStock1.locoweight = this.TrainMass;
   this.SelectedStock1.locolength = "d";
   this.SelectedStock1.totalweight ="e";
   this.SelectedStock1.totallength ="a";


    



    alert("child");
    this.props.name(this.SelectedStock1);

    // this.props.name(JSON.stringify(this.SelectedStock1));
  };

  
  PopulateLocoList() {
    let LocoList = [];
    LocoList.push(new Loco("", 0, 0));
    LocoList.push(new Loco("WAP4", 113, 19));
    LocoList.push(new Loco("WAP5", 78, 18));
    LocoList.push(new Loco("WAP7", 123, 20));
    LocoList.push(new Loco("T18", 78, 25));
    LocoList.push(new Loco("WAG5", 119, 17));
    LocoList.push(new Loco("WAG7", 123, 21));
    LocoList.push(new Loco("WAG9", 123, 20));
    LocoList.push(new Loco("EMU", 120, 120));
    LocoList.push(new Loco("4KHP100", 123, 20));
    LocoList.push(new Loco("5KHP100", 123, 20));
    LocoList.push(new Loco("6KHP100", 123, 20));
    return LocoList;
  }

   PopulateStockList() {
    let StockList = [];
    StockList.push(new Stock("","", 0, 0,0));
    StockList.push(new Stock("COACH","LHB", 43, 48, 24));
    StockList.push(new Stock("COACH","ICF", 45, 50, 22));
    StockList.push(new Stock("COACH","HYBRID", 43, 48, 24));
    StockList.push(new Stock("COACH", "EMU", 15, 20, 22));
    StockList.push(new Stock("COACH", "DMU", 15, 20, 22));
    StockList.push(new Stock("COACH", "MEMU", 15, 20, 22));
    StockList.push(new Stock("WAGON","BCN", 20, 92, 15));
    StockList.push(new Stock("WAGON","BOXN", 20, 92, 10));
    StockList.push(new Stock("WAGON","CONTAINER", 5, 27, 12));
    StockList.push(new Stock("COACH", "T18", 43, 48, 22));
    return StockList;

}


 LocoList=this.PopulateLocoList();
 StockList=this.PopulateStockList();
  SelectedLoco = new Loco();
  SelectedStock = new Stock();

  loco;
  NoOfLoco=1;
  stock;
  NoOfStock=0;
  AdhessiveMassInTons;
  TrailingLoadInTons;
  TrainMass;
  TrainLength;

  testvar;
  LocoType;
  LocoCount;
  StockType;
  StockCount;
 
  setValues() {

    alert("ok");
    alert(this.props.name);


  
   this.SelectedLoco = this.LocoList.find(a => a.LocoType === this.LocoType);
   this.SelectedStock = this.StockList.find(a => a.StockType === this.StockType.toString());

   this.NoOfLoco = parseInt((this.LocoCount == null ? "0" : this.LocoCount.toString())); 
   this.NoOfStock = parseInt(this.StockCount == null ? "0" : this.StockCount.toString());

   if (this.SelectedLoco !== undefined && this.NoOfLoco !== undefined) 
   {
    this.AdhessiveMassInTons =  this.SelectedLoco.Weight * this.NoOfLoco; 
   }
   else
   {
    this.AdhessiveMassInTons= "";
   }

   if (this.SelectedStock !== undefined && this.NoOfStock !== undefined) 
   {
    this.TrailingLoadInTons = this.SelectedStock.LoadedWeight * this.NoOfStock;
    
   }
   else
   {
    this.TrailingLoadInTons= "";
   }

   if (this.AdhessiveMassInTons !== undefined && this.TrailingLoadInTons !== undefined) 
   {
    this.TrainMass = this.AdhessiveMassInTons + this.TrailingLoadInTons;
   }
   else
   {
    this.TrainMass= "";
   }

   if (this.SelectedLoco !== undefined && this.NoOfLoco !== undefined && this.SelectedStock !== undefined && this.NoOfStock !== undefined) 
   {
    this.TrainLength = parseInt(this.SelectedStock.Length * this.NoOfStock + this.SelectedLoco.Length * this.NoOfLoco); 
   }
   else
   {
    this.TrainLength= "";
   }
   this.setState({text1: this.AdhessiveMassInTons});
   this.setState({text2: this.TrailingLoadInTons});
   this.setState({text3: this.TrainMass});
   this.setState({text4: this.TrainLength});
 

 }
 


  constructor(props) {
    super(props);

    this.state = {
      text1: '',
      text2: '',
      text3: '',
      text4: '',
      LocoType: '',
      LocoCount: '',
      StockType: '',
      StockCount: '',
     // LocoList:this.PopulateLocoList(),
     // StockList : this.PopulateStockList()
    };


    this.LocoList = this.PopulateLocoList();
    this.StockList=this.PopulateStockList();
    
  }

  handleTextChange = (event, fieldName) => {
   
    alert(event.target.value);
    alert(fieldName);
    //this.state.text1:"aa";
   /// this.setState({text2:event.target.value});
   // this.setState({text3:event.target.value});
   // this.setState({text4:event.target.value});
   // this.setState({ [fieldName]: event.target.value });
  };

  handleLocoTypeChange = (event, fieldName) => {

    this.setState({LocoType: event.target.value });
    this.LocoType=event.target.value;
    this.setValues();

  
  };


  handleLocoCountChange = (event, fieldName) => {

   

    this.setState({LocoType: event.target.value });
    this.LocoCount=event.target.value;
   

    this.setValues();
  };



  handleStockTypeChange = (event, fieldName) => {

  

    this.setState({StockType: event.target.value });
    this.StockType=event.target.value;
    

    this.setValues();
  };


  handleStockCountChange = (event, fieldName) => {

   

    this.setState({StockCount: event.target.value });
    this.StockCount=event.target.value;
    

    this.setValues();
  };

  handleComboChange = (event, fieldName) => {
    alert(event.target.value);
    alert(fieldName);
    this.setState({text1:event.target.value});
    alert(this.state.text1);    
    this.setState({ [fieldName]: event.target.value });
    
    if(fieldName==="LocoType")
    {

      this.setState({LocoType:event.target.value});
    } 

   
    if(fieldName==="StockCount")
    {

      this.setState({StockCount:event.target.value});
    } 

    if(fieldName==="StockType")
    {
      this.setState({StockType:event.target.value});

    } 

    if(fieldName==="LocoCount")
    {
      this.setState({LocoCount:event.target.value});

    } 

    alert(this.state.LocoType);
      this.setValues();


  };


  componentDidUpdate(prevProps, prevState)
  {


   
  }

  render() {
    return (
      <div>
         
       
      <br/>
<table align='center'>
  <tr>
    <td width={200}>
      <label style={{width: "100px", textAlign:'center', fontWeight:'bold'}} htmlFor="input-field">Loco Type</label>
    </td>
    <td width={200}>
      <label style={{width: "100px", textAlign:'center', fontWeight:'bold'}} htmlFor="input-field">Loco Count</label>
    </td>
    <td width={200}>
      <label style={{width: "100px", textAlign:'center', fontWeight:'bold'}} htmlFor="input-field">Stock Type</label>
    </td>
    <td width={200}>
      <label style={{width: "100px", textAlign:'center', fontWeight:'bold'}} htmlFor="input-field">Stock Count</label>
    </td>
    </tr>
    <tr>
    <td width={200}>
    <select style={{width: "100px", textAlign:'center', color:'blue', fontSize:'16', fontWeight:'bold'}} name="t1" id="comboById" value={this.LocoType} onChange={(e) => this.handleLocoTypeChange(e, 'LocoType')}>       
          <option value=""></option>
          <option value="T18">T18</option>
          <option value="WAP5">WAP5</option>
          <option value="WAP7">WAP7</option>
          <option value="WDM4">WDM4</option>
          <option value="WDM6">WDM6</option>
          <option value="WAG5">WAG5</option>
          <option value="WAG7">WAG7</option>
          <option value="WAG9">WAG9</option>
          <option value="EMU">EMU</option>
          <option value="4KHP100">4KHP100</option>
          <option value="5KHP100">5KHP100</option>
          <option value="6KHP100">6KHP100</option>
        </select>
    </td>
    <td width={200}>
      <select style={{width: "100px", textAlign:'center', color:'blue', fontSize:'16', fontWeight:'bold'}} value={this.LocoCount} onChange={(e) => this.handleLocoCountChange(e, 'LocoCount')}>
          <option value=""></option>
          <option value="1">1</option>
          <option value="2">2</option>
      </select>
    </td>
    <td width={200}>
    <select style={{width: "100px", textAlign:'center', color:'blue', fontSize:'16', fontWeight:'bold'}} value={this.StockType} onChange={(e) => this.handleStockTypeChange(e, 'StockType')}>
          <option value=""></option>
          <option value="T18">T18</option>
          <option value="LHB">LHB</option>
          <option value="HYBRID">HYBRID</option>
          <option value="ICF">ICF</option>
          <option value="MEMU">MEMU</option>
          <option value="DMU">DMU</option>
          <option value="EMU">EMU</option>
          <option value="CONTAINER">CONTAINER</option>
          <option value="BCN">BCN</option>
          <option value="BOXN">BOXN</option>    
        </select>
    </td>
    <td width={200}>
    <select style={{width: "100px", textAlign:'center', color:'blue', fontSize:'16', fontWeight:'bold'}} value={this.StockCount} onChange={(e) => this.handleStockCountChange(e, 'StockCount')}>
          <option value=""></option>
          <option value="12">12</option>
          <option value="14">14</option>
          <option value="16">16</option>
          <option value="18">18</option>
          <option value="20">20</option>
          <option value="22">22</option>
          <option value="24">24</option>
          <option value="40">40</option>
          <option value="42">42</option>
          <option value="44">44</option>
          <option value="46">46</option>
          <option value="48">48</option>
          <option value="50">50</option>
          <option value="52">52</option>
          <option value="54">54</option>
          <option value="56">56</option>
          <option value="58">58</option>
          <option value="60">60</option>
        </select>
    </td>
  </tr>
  <tr>
    <td width={200}>
      <label style={{width: "100px", textAlign:'center', fontWeight:'bold'}} htmlFor="input-field">Loco Weight (Tonnes)</label>
    </td>
    <td width={200}>
      <label style={{width: "100px", textAlign:'center', fontWeight:'bold'}} htmlFor="input-field">Trailing Load (Tonnes)</label>
    </td>
    <td width={200}>
      <label style={{width: "100px", textAlign:'center', fontWeight:'bold'}} htmlFor="input-field">Train Mass (Tonnes)</label>
    </td>
    <td width={200}>
      <label style={{width: "100px", textAlign:'center', fontWeight:'bold'}} htmlFor="input-field">Trailing Length (Meters)</label>
    </td>
  </tr>
  <tr>
    <td>
    <input style={{width: "100px", textAlign:'center', fontSize:'16', color:'blue', fontWeight:'bold'}}  type="text" value={this.state.text1} onChange={(e) => this.handleTextChange(e, 'text1')} />
    </td>
    <td>
    <input style={{width: "100px", textAlign:'center', fontSize:'16', color:'blue', fontWeight:'bold'}}  type="text" value={this.state.text2} onChange={(e) => this.handleTextChange(e, 'text2')} />
    </td>
    <td>
    <input style={{width: "100px", textAlign:'center', fontSize:'16', color:'blue', fontWeight:'bold'}}  type="text" value={this.state.text3} onChange={(e) => this.handleTextChange(e, 'text3')}/>
    </td>
    <td>
    <input style={{width: "100px", textAlign:'center', fontSize:'16', color:'blue', fontWeight:'bold'}}  type="text" value={this.state.text4} onChange={(e) => this.handleTextChange(e, 'text4')} />
    </td>
  </tr>
  <tr>
    <td colSpan={2} align='center'>
      <button style={{width: "310px", fontSize:'16', color:'blue', fontWeight:'bold'}} onClick={this.setValues}>Simulate</button>
    </td>
    <td colSpan={2} align='center'>
      <button style={{width: "310px", fontSize:'16', color:'blue', fontWeight:'bold'}} onClick={this.sendDataToParent}>Export data cp</button>
    </td>
  </tr>
</table>


      </div>
    );
  }
}

export default InputComponent;
