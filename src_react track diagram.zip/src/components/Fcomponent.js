import React, { useState, useEffect } from 'react';

function DataFetcherFunction() {
  const [data, setData] = useState(null);

  useEffect(() => {
    fetch('https://api.example.com/data')
      .then(response => response.json())
      .then(data => {
        setData(data);
      });
  }, []); // Empty array means run the effect only once (like componentDidMount)

  return (
    <div>
      <p>Data: {data}</p>
    </div>
  );
}

export default DataFetcherFunction;
