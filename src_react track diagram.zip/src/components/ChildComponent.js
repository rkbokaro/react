/* eslint-disable react/prop-types */
import React, { useState } from 'react';

function ChildComponent(props) {
  const [gridData, setGridData] = useState([]);

  const handleClick = async () => {
    // const urtstrPsr = "http://localhost:8086/PsrInfra/SPJ-BLRI-UJP-NAZJ-BSRA-DSS-STJT-BCA-MPNH-TGA-BUJ-BJU-GHX-DKGS-BTPH-RJO-HTZU-RDUM-JLPH-BRYA-GGSY-DMRX-DJS-MKB-LKR-KIUL";
	const urtstrPsr = "http://localhost:8086/PsrInfra1/MKB-LKR-KIUL";

    try {
		alert("start	");
      const response = await fetch(urtstrPsr);
      const result1 = await response.json();
		setGridData(result1.scheduleList);

		alert(result1)
		alert(gridData[0].stationCode)
		alert(gridData[1].arrival)
		alert(gridData[2].stationCode)
		//alert(result1.scheduleList[0].stationCode)
    } catch (error) {
      console.error('Error:', error);
    }
  };

  return (
    <div>
      <button onClick={() => props.greetHandler()}>Call Parent Component</button>

      <button onClick={handleClick}>Fetch and Populate Grid</button>

      <div>
        <table>
          <thead>
            <tr>
              <th>Station</th>
              <th>Arrival</th>
              <th>Departure</th>
              {/* Add more headers based on your data */}
            </tr>
          </thead>
          <tbody>
            {gridData.map((item, index) => (
				
              <tr key={index}>
                <td>{item.stationCode}</td>
                <td>{ new Date(item.arrival * 1000).toISOString().substr(11, 8)}</td>
                <td>{ new Date(item.departure * 1000).toISOString().substr(11, 8) }</td>
                {/* Add more cells based on your data */}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default ChildComponent;
