function App() {
    const chartData1 = {
      labels: ['A', 'B', 'C'], // Pass the labels here
      data: [10, 20, 15],
      backgroundColor: 'rgba(255, 99, 132, 0.2)',
      borderColor: 'rgba(255, 99, 132, 1)',
    };
  
    const chartData2 = {
      labels: ['X', 'Y', 'Z'], // Pass the labels here
      data: [5, 12, 8],
      backgroundColor: 'rgba(54, 162, 235, 0.2)',
      borderColor: 'rgba(54, 162, 235, 1)',
  };
  
  
  
    return (
      <div className="App">
        <h1>Bar Chart Example</h1>
        <BarChart chartData={chartData1} />
        <BarChart chartData={chartData2} />
      </div>
    );
  }
  