/* eslint-disable no-empty */
/* eslint-disable react/jsx-key */
/* eslint-disable react/jsx-no-comment-textnodes */
/* eslint-disable react/no-unescaped-entities */
/* eslint-disable react/no-unknown-property */
/* eslint-disable no-inner-declarations */
/* eslint-disable no-unused-vars */


//import React from 'react';
import React, { Component } from 'react';
import './App.css';
import * as XLSX from 'xlsx';
import ParentComponent from './components/ParentComponent';
import ParentComponent1 from './components/ParentComponent1';
import InputComponent from './components/InputComponent';
import AnotherChildComponent from './components/AnotherChildComponent';

import { SimulateWithParameter } from './components/TPCFUNC';
import MyContext from "./MyContext";

import ComboComponent from './components/ComboComponent';
//import AnotherChildComponent from './components/AnotherChildComponent';
import axios from 'axios';
import ChildComponent from './components/ChildComponent';



// class RouteKilometer {
//   constructor() {
//       this.EffectiveCurveAngle = 0;
//       this.EffectiveGradeValue = 0;
//       this.EffectiveMaximumSpeed = 0;
//       this.MilePost = 0;
//       this.CurveAngle = 0;
//       this.CurveRadius = 0;
//       this.CurveSide = 0;
//       this.GradeValue = 0;
//       this.MaximumSpeed = 0;
//       this.Position = "";
//       this.SpeedRestrictionType = "";
//       this.StoppageFlag = false;
//       this.StoppageTime = 0;
//   }
// }


class Route {
  constructor() {
    this.routecode = "";
    this.location = location;
    this.sflag = "";
    this.Stime = 0;
    this.sectionspeed = 0;
    this.gradevalue = 0;
    this.curvevalue = 0;
    this.psrspeed = 0;
    this.maxpermissiblespeed = 0;
    this.EffectiveCurveAngle = 0;
    this.EffectiveGradeValue = 0;
    this.EffectiveMaximumSpeed = 0;
    this.MilePost = 0;
    this.CurveAngle = 0;
    this.CurveRadius = 0;
    this.CurveSide = 0;
    this.GradeValue = 0;
    this.MaximumSpeed = 0;
    this.Position = "";
    this.SpeedRestrictionType = "";
    this.StoppageFlag = false;
    this.StoppageTime = 0;
  }

  
}



// class Route {
//   constructor(routecode, location, sflag, stime, sectionspeed, gradevalue, curvevalue, psrspeed, maxpermissiblespeed) {
//     this.routecode = routecode;
//     this.location = location;
//     this.sflag = sflag;
//     this.Stime = stime;
//     this.sectionspeed = sectionspeed;
//     this.gradevalue = gradevalue;
//     this.curvevalue = curvevalue;
//     this.psrspeed = psrspeed;
//     this.maxpermissiblespeed = maxpermissiblespeed;
//     this.EffectiveCurveAngle = 0;
//     this.EffectiveGradeValue = 0;
//     this.EffectiveMaximumSpeed = 0;
//     this.MilePost = 0;
//     this.CurveAngle = 0;
//     this.CurveRadius = 0;
//     this.CurveSide = 0;
//     this.GradeValue = 0;
//     this.MaximumSpeed = 0;
//     this.Position = "";
//     this.SpeedRestrictionType = "";
//     this.StoppageFlag = false;
//     this.StoppageTime = 0;
//   }

  
// }

class App extends React.Component {

  async fetchData() {
    try {
      const response1 = await axios.get(this.urtstr1);
      const routedistance1 = response1.data[response1.data.length - 1].cumulativeDistance
      this.setState({ routedistance: response1.data[response1.data.length - 1].cumulativeDistance });
      const response2 = await axios.get(this.urtstrPsr);
      const response3 = await axios.get(this.urtstrCurvature);
      const response4 = await axios.get(this.urtstrGradient);


      const users1 = response1.data;
      const Psrdata1 = response2.data;
      const Curvaturedata1 = response3.data;
      const Gradientdata1 = response4.data;






      let Routelist = [];

      users1.forEach(myFunction);
      function myFunction(item) {
        for (let index = item.cumulativeDistance * 1000; index < (item.cumulativeDistance + item.interDistance) * 1000; index++) {
          let route1 = new Route();
          route1.speedvalue = item.maxspeed;
          route1.gradevalue = 0;
          route1.curvevalue = 0;
          Routelist.push(route1);

        }
      }


      Gradientdata1.forEach(gradientFunction);
      function gradientFunction(item) {
        for (let index = Math.min(item.grade_SelectedRoute_FromKm, item.grade_SelectedRoute_UptoKm) * 1000; index < Math.min(Math.max(item.grade_SelectedRoute_FromKm, item.grade_SelectedRoute_UptoKm), routedistance1) * 1000; index++) {

          Routelist[index].gradevalue = item.grade_Value;

        }
      }


      Curvaturedata1.forEach(curvatureFunction);
      function curvatureFunction(item) {
        for (let index = Math.min(item.curve_SelectedRoute_FromKm, item.curve_SelectedRoute_UptoKm) * 1000; index < Math.max(item.curve_SelectedRoute_FromKm, item.curve_SelectedRoute_UptoKm) * 1000; index++) {

          Routelist[index].curvevalue = item.curve_AngleInDegree;
        }
      }

      Psrdata1.forEach(psrFunction);
      function psrFunction(item) {
        for (let index = Math.min(item.psr_SelectedRoute_FromKm, item.psr_SelectedRoute_UptoKm) * 1000; index < Math.max(item.psr_SelectedRoute_FromKm, item.psr_SelectedRoute_UptoKm) * 1000; index++) {

          Routelist[index].psrspeed = item.psr_PSpeedKmph;
          Routelist[index].maxpermissiblespeed = Math.min(Routelist[index].psrspeed, Routelist[index].sectionspeed);

        }
      }


      for (let index = 0; index < routedistance1 * 1000; index++) {


        let route1 = new Route();
        let psrvalue = Math.min(Psrdata1.filter(a => a.psr_SelectedRoute_FromKm * 1000 <= index && a.psr_SelectedRoute_UptoKm * 1000 >= index).map(b => Math.min(b.sctnspeed, b.psr_PSpeedKmph)));
        let Gradientvalue = Gradientdata1.filter(a => a.grade_SelectedRoute_FromKm * 1000 <= index && a.grade_SelectedRoute_UptoKm * 1000 >= index).map(b => b.grade_Value);
        let curvaturevalue = Curvaturedata1.filter(a => a.curve_SelectedRoute_FromKm * 1000 <= index && a.curve_SelectedRoute_UptoKm * 1000 >= index).map(b => b.curve_AngleInDegree);
        let stationvalue = users1.filter(a => a.cumulativeDistance * 1000 === index);
        if (stationvalue === undefined) {
          stationvalue = this.state.users.find(a => a.cumulativeDistance <= index && (a.cumulativeDistance * 1000 + a.interDistance * 1000) >= index);
          route1 = stationvalue.blockSection;
        }
        else if (stationvalue !== undefined) {
          route1.routecode = stationvalue[0].stationCode;
        }




        route1.location = 1;
        route1.routecode = stationvalue[0].stationCode;
        route1.psrvalue = psrvalue;
        route1.gradevalue = Gradientvalue;

        route1.curvevalue = curvaturevalue;



        Routelist.push(route1);


      }


      //  this.setState({ data1, data2 });
    } catch (error) {
      console.error(error);
    }
  }



  exportToExcel1 = () => {

    this.setState({ rotateAngle: "rotate(90, 500 500)" });

    setTimeout(5000);


    // window.print();
  }




  exportToExcel2 = () => {

    // this.setState({ rotateAngle:"rotate(90, 500 500)" });

    //setTimeout("",5000);


    window.print();
  }
  exportToExcel = () => {



    // window.print();
    alert("ok");
    alert(this.state.routedistance);
    alert(this.state.Psrdata);


    const data = [
      ['Name', 'Age', 'Gender'],
      ['John', 25, 'Male'],
      ['Jane', 30, 'Female'],
      ['Bob', 20, 'Male'],
    ];



    const columnsPSR =
      [
        'seqnumber',
        'sttncode',
        'coablcksctn',
        'cum_DISTANCE',
        'distance',
        'station_milepost_I',
        'station_milepost_II',
        'station_milepost_III',
        'psr_RefMilePost_FromKm',
        'psr_RefMilePost_FromSubKm',
        'psr_RefMilePost_UptoKm',
        'psr_RefMilePost_UptoSubKm',
        'psr_LengthAsGiven',
        'psr_SelectedRoute_FromKm',
        'psr_SelectedRoute_UptoKm',
        'psr_Calculated_Length',
        'psr_PSpeedKmph',
        'psr_GSpeedKmph',
        'sctnspeed',
        'psr_StopDeadFlag',
        'psr_PermanentTemporaryFlag',
        'psr_PTimeLoss',
        'psr_GTimeLoss',
        'psr_ApplicableFromTime',
        'psr_ApplicableUptoTime',
        'psr_ValidFromDate',
        'psr_ValidUptoDate'
      ];




    const columnsGradient =
      [
        'seqnumber',
        'sttncode',
        'coablcksctn',
        'distance',
        'cum_DISTANCE',
        'grade_RefMilePost_FromRefStation',
        'grade_RefMilePost_FromKm',
        'grade_RefMilePost_FromSubKm',
        'grade_RefMilePost_UptoKm',
        'grade_RefMilePost_UptoSubKm',
        'grade_LengthAsGiven',
        'grade_Calculated_Length',
        'grade_Type',
        'grade_Value',
        'gradientvalue',
        'psr_SelectedRoute_UptoKm',
        'psr_Calculated_Length',
        'grade_PTimeLoss',
        'grade_GTimeLoss',
        'grade_Remark',
        'grade_SelectedRoute_FromKm',
        'grade_SelectedRoute_UptoKm'
      ];

    const columnsCurvature =
      [
        'seqnumber',
        'sttncode',
        'coablcksctn',
        'distance',
        'cum_DISTANCE',
        'curve_RefMilePost_UptoSubKm',
        'curve_SelectedRoute_FromKm',
        'curve_Calculated_Length',
        'curve_RefMilePost_UptoKm',
        'curve_SelectedRoute_UptoKm',
        'curve_RefMilePost_FromSubKm',
        'curve_RefMilePost_FromKm',
        'curve_LengthAsGiven',
        'curve_RadiusInMeter',
        'curve_AngleInDegree',


        'curve_PTimeLoss',
        'curve_GTimeLoss',
        'curve_Remark',
        'sctnspeed',
        'curve_RefMilePost_FromRefStation'

      ];


    const columnsstation =
      [
        'stationSeq',
        'stationCode',
        'stationName',
        'stationClass',
        'blockSection',
        'interDistance',
        'cumulativeDistance',
        'blockSectionLineCount',
        'stationLineCount',
        'platformCount',
        'stationAdjacencyCount',
        'allConnectionCount',
        'nextConnectionCount',
        'prevConnectionCount',

        'stationAdjacency',
        'stationLines',
        'stationPlatforms',
        'blockSectionLines',
        'allConnections',
        'nextConnections',
        'prevConnections',

        'stationMilePost',
        'prevStationDistance',
        'nextStationDistance',

        'platformList',
        'stationLineList',
        'stationLineList',
        'stationAdjacencyList',
        'allConnectionList',
        'nextConnectionList',
        'prevConnectionList',
        'blockSectionLineList',
        'refsttn',
        'milepostsubkm',
        'milepostkm'
      ];








    // convert data to worksheet
    //const worksheet = XLSX.utils.json_to_sheet(data, { header: columns });

    const fileName = 'sample-data.xlsx';
    alert(data);
    const worksheet = XLSX.utils.json_to_sheet(this.state.users, { header: columnsstation });
    const worksheet1 = XLSX.utils.json_to_sheet(this.state.Psrdata, { header: columnsPSR });
    const worksheet2 = XLSX.utils.json_to_sheet(this.state.Gradientdata, { header: columnsGradient });
    const worksheet3 = XLSX.utils.json_to_sheet(this.state.Curvaturedata, { header: columnsCurvature });
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Station');
    XLSX.utils.book_append_sheet(workbook, worksheet1, 'PSR');
    XLSX.utils.book_append_sheet(workbook, worksheet2, 'Grade');
    XLSX.utils.book_append_sheet(workbook, worksheet3, 'Curve');
    XLSX.writeFile(workbook, fileName);
  };


  svgStyle = {
    transform: 'rotate(90deg)',
    transformOrigin: '500px 500px',
  }
  rotateAngle = "rotate(0, 500 500)";
  offsetX = 100.0;
  offsetY = 70.0;
  lineGapVertical = 40.0;
  lineWidth = 100.0;
  linenameWidth = 40.0;
  lineThickness = 2.5;
  platformThickness = 8.0;
  platformWidth = 100.0;
  distanceScale = 100.0;
  platformFontsize = 8.0;
  linenameFontsize = 9.0;
  stationcodeFontsize = 12.0;
  stationameFontsize = 10.0;
  interdistanceFontsize = 10.0;
  connectionGap = 50.0;
  linecolor1 = "blue";
  linecolor2 = "red";
  dasharraybroken = "25, 10";
  dasharraysolid = "25, 0";
  routedistance = 100.0;
  offsetYPSR = 750.0;
  offsetYGrade = 1000.0;
  maxSpeedLimit = 200;
  Speeds = [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120, 130, 140, 150, 160, 180, 210];


  currentLevel = 0;
  currentLevel1 = 0;

  offsetYCurvature = 1200;

  testvar = 0;


  polygonpoints = this.offsetX + "," + this.offsetYPSR;
  gradePolygonPoints = this.offsetX + "," + this.offsetYGrade;
  curvaturepolygonpoints = this.offsetX + "," + this.offsetYCurvature;


  currgradepoints = "";
  currCurvePoints = "";

  testpoint = "";



  //"100,950,158,915,208,910,208,915,308,910,308,915,393,910,393,915,517,910,517,915,563,910,563,915,692,910,692,915,723,910,723,915,1054,910,1084.5,915,1086.5,910,1086.5,915,1295.5,910,1295.5,915,1313.5,910,1313.5,915,1358.5,910,1358.5,915,1400.5,910,1400.5,915,1478.5,910,1478.5,915,1488.5,910,1488.5,915,1570.5,910,1570.5,915,1580.5,910,1580.5,915,1688.5,910,1679.1000000000001,915,1704.1000000000001,910,1703.9,915,1679.1000000000001,910,1704.1000000000001,915,1751.1,910,1751.1,915,1824.1,910,1824.1,915,1854.1000000000001,910,1854.1000000000001,915,1904.1000000000001,910,1904.1000000000001,915,1959.1000000000001,910,1959.1000000000001,915,2083.1,910,2083.1,915,2108.1,910,2108.1,915,2232.1000000000004,910,2232.1000000000004,915,2272.1,910,2272.1,915,2372.1,910,2444.7,915,2470.7000000000003,910,2470.7000000000003,915,2591.7000000000003,910,2591.7000000000003,915,2607.7000000000003,910,2607.7000000000003,915,2644.7,910,2644.7,915,2668.7000000000003,910,2668.7000000000003,915,2766.7000000000003,910,2766.7000000000003,915,2775.7000000000003,910,2775.7000000000003,915,2836.7000000000003,910,2836.7000000000003,915,2844.7,910,2996.6,915,3069.4,910,3069.4,915,3134.4,910,3134.4,915,3162.4,910,3162.4,915,3229.4,910,3229.4,915,3319.4,910,3319.4,915,3331.4,910,3331.4,915,3355.4,910,3355.4,915,3386.3999999999996,910,3386.3999999999996,915,3509.4,910,3574.7,915,3599.7,910,3599.7,915,3654.7,910,3635.3,915,3574.7,910,3654.7,915,3734.7000000000003,910,3734.7000000000003,915,3749.7,910,3749.7,915,3904.7,910,3904.7,915,3929.7,910,3929.7,915,4094.7000000000003,910,4094.7000000000003,915,4109.700000000001,910,4109.700000000001,915,4279.7,910,4279.7,915,4294.700000000001,910,4294.700000000001,915,4529.7,910,4696.200000000001,915,5061.2,910,5061.2,915,  5144.2,910,5754.4,915,5779.4,910,6010.7,915,6077.3,910,6205.7,915,6077.3,910,6255.7,915,6205.7,910,6289.3,915,6319.700000000001,910,6409.3,915,6289.3,910,6494.3,915,6409.3,910,6670.999999999999,915,
  gpoint = "100,950,158,915,208,910,208,915,308,910,308,915,393,910,393,915,517,910,517,915,563,910,563,915,692,910,692,915,723,910,723,915,1054,910,1084.5,915,1086.5,910,1086.5,915,1295.5,910,1295.5,915,1313.5,910,1313.5,915,1358.5,910,1358.5,915,1400.5,910,1400.5,915,1478.5,910,1478.5,915,1488.5,910,1488.5,915,1570.5,910,1570.5,915,1580.5,910,1580.5,915,1688.5,910,1679.1000000000001,915,1704.1000000000001,910,1703.9,915,1679.1000000000001,910,1704.1000000000001,915,1751.1,910,1751.1,915,1824.1,910,1824.1,915,1854.1000000000001,910,1854.1000000000001,915,1904.1000000000001,910,1904.1000000000001,915,1959.1000000000001,910,1959.1000000000001,915,2083.1,910,2083.1,915,2108.1,910,2108.1,915,2232.1000000000004,910,2232.1000000000004,915,2272.1,910,2272.1,915,2372.1,910,2444.7,915,2470.7000000000003,910,2470.7000000000003,915,2591.7000000000003,910,2591.7000000000003,915,2607.7000000000003,910,2607.7000000000003,915,2644.7,910,2644.7,915,2668.7000000000003,910,2668.7000000000003,915,2766.7000000000003,910,2766.7000000000003,915,2775.7000000000003,910,2775.7000000000003,915,2836.7000000000003,910,2836.7000000000003,915,2844.7,910,2996.6,915,3069.4,910,3069.4,915,3134.4,910,3134.4,915,3162.4,910,3162.4,915,3229.4,910,3229.4,915,3319.4,910,3319.4,915,3331.4,910,3331.4,915,3355.4,910,3355.4,915,3386.3999999999996,910,3386.3999999999996,915,3509.4,910,3574.7,915,3599.7,910,3599.7,915,3654.7,910,3635.3,915,3574.7,910,3654.7,915,3734.7000000000003,910,3734.7000000000003,915,3749.7,910,3749.7,915,3904.7,910,3904.7,915,3929.7,910,3929.7,915,4094.7000000000003,910,4094.7000000000003,915,4109.700000000001,910,4109.700000000001,915,4279.7,910,4279.7,915,4294.700000000001,910,4294.700000000001,915,4529.7,910,4696.200000000001,915,5061.2,910,5061.2,915,  5144.2,910,5754.4,915,5779.4,910,6010.7,915,6077.3,910,6205.7,915,6077.3,910,6255.7,915,6205.7,910,6289.3,915,6319.700000000001,910,6409.3,915,6289.3,910,6494.3,915,6409.3,910,6670.999999999999,915,7272.7,910,7942.799999999999,915,7949.299999999999,910,7999.299999999999,915,8064.3,910,8458.9,915,8608.9,910,8885.5,915,8995.5,910";
  cpoint = "100,1200,556.4,1200,556.4,1160,613.4000000000001,1160,613.4000000000001,1200,629.5,1200,629.5,1180,639.5,1180,639.5,1200,637,1200,637,1185,646,1185,646,1200," +
    "647.1,1200,647.1,1185,761.1,1185,761.1,1200,725.4,1200,725.4,1160,769.4,1160,769.4,1200,926.3,1200,926.3,1180,939.3000000000001,1180,939.3000000000001,1200,959.2,1200," +
    "959.2,1180,975.2,1180,975.2,1200,1052.2,1200,1052.2,1185,1066.2,1185,1066.2,1200,1088.4,1200,1088.4,1185,1102.3999999999999,1185,1102.3999999999999,1200,1577.8,1200," +
    "1577.8,1180,1596.8,1180,1596.8,1200,1607,1200,1607,1180,1632,1180,1632,1200,1667.8000000000002,1200,1667.8000000000002,1180,1688.8,1180,1688.8,1200,1697.4,1200,1697.4,1180," +
    "1719.3999999999999,1180,1719.3999999999999,1200,1890.2,1200,1890.2,1160,1959.1999999999998,1160,1959.1999999999998,1200,2232.9,1200,2232.9,1180,2257.9,1180,2257.9,1200," +
    "2325.2,1200,2325.2,1176,2356.2000000000003,1176," +
    "2356.2000000000003,1200,2501.3,1200,2501.3,1170,2519.3,1170,2519.3,1200,2684.7999999999997,1200,2684.7999999999997,1180,2702.7999999999997,1180," +
    "2702.7999999999997,1200,2989.5,1200,2989.5,1180,3027.5,1180,3027.5,1200,3075.1,1200,3075.1,1145,3138.1,1145,3138.1,1200,3161,1200,3161,1160,3226,1160,3226,1200," +
    "3255.6,1200,3255.6,1180,3294.6000000000004,1180,3294.6000000000004,1200,3559.7000000000003,1200,3559.7000000000003,1160,3579.7,1160,3579.7,1200,3582.7,1200,3582.7,1160," +
    "3599.7,1160,3599.7,1200,4014.5000000000005,1200,4014.5000000000005,1185,4069.5,1185,4069.5,1200,4652.5,1200,4652.5,1185,4856.2,1185,4856.2,1200,5804.3,1200,5804.3,1140," +
    "5903.099999999999,1140,5903.099999999999,1200,5959.2,1200,5959.2,1200,6352.6,1200,6352.6,1200,6233,1200,6233,1165,6334.1,1165,6334.1,1200,6533.1,1200,6533.1,1180,6534.2,1180,6534.2,1200," +
    "6670.999999999999,1200,6670.999999999999,1200,7269.799999999999,1200," +
    "7269.799999999999,1200,7557.099999999999,1200,7557.099999999999,1185," +
    "7657.299999999999,1185,7657.299999999999,1200,8506.1,1200," +
    "8506.1,1180,8705.9,1180,8705.9,1200,8777.9,1200,8777.9,1200,8872,1200,8872,1200";

   
  //urtstrRolldiagram = "http://webclientapp.ap-south-1.elasticbeanstalk.com/RollDiagram?RouteString=SPJ-BLRI-UJP-NAZJ-BSRA-DSS-STJT-BCA-MPNH-TGA-BUJ-BJU-GHX-DKGS-BTPH-RJO-HTZU-RDUM-JLPH-BRYA-GGSY-DMRX-DJS-MKB-LKR-KIUL";

  urtstrPsr = "http://localhost:8086/PsrInfra/SPJ-BLRI-UJP-NAZJ-BSRA-DSS-STJT-BCA-MPNH-TGA-BUJ-BJU-GHX-DKGS-BTPH-RJO-HTZU-RDUM-JLPH-BRYA-GGSY-DMRX-DJS-MKB-LKR-KIUL";
  urtstrCurvature = "http://localhost:8086/CurvatureInfra/SPJ-BLRI-UJP-NAZJ-BSRA-DSS-STJT-BCA-MPNH-TGA-BUJ-BJU-GHX-DKGS-BTPH-RJO-HTZU-RDUM-JLPH-BRYA-GGSY-DMRX-DJS-MKB-LKR-KIUL";
  urtstrGradient = "http://localhost:8086/GradientInfra/SPJ-BLRI-UJP-NAZJ-BSRA-DSS-STJT-BCA-MPNH-TGA-BUJ-BJU-GHX-DKGS-BTPH-RJO-HTZU-RDUM-JLPH-BRYA-GGSY-DMRX-DJS-MKB-LKR-KIUL";
  urtstr1 = "http://localhost:8086/RollDiagramInfra/SPJ-BLRI-UJP-NAZJ-BSRA-DSS-STJT-BCA-MPNH-TGA-BUJ-BJU-GHX-DKGS-BTPH-RJO-HTZU-RDUM-JLPH-BRYA-GGSY-DMRX-DJS-MKB-LKR-KIUL";


  // urtstrPsr = "http://localhost:7005/PsrInfra?RouteString=SPJ-BLRI-UJP-NAZJ-BSRA-DSS-STJT-BCA-MPNH-TGA-BUJ-BJU-GHX-DKGS-BTPH-RJO-HTZU-RDUM-JLPH-BRYA-GGSY-DMRX-DJS-MKB-LKR-KIUL";
  // urtstrCurvature = "http://localhost:7005/CurvatureInfra?RouteString=SPJ-BLRI-UJP-NAZJ-BSRA-DSS-STJT-BCA-MPNH-TGA-BUJ-BJU-GHX-DKGS-BTPH-RJO-HTZU-RDUM-JLPH-BRYA-GGSY-DMRX-DJS-MKB-LKR-KIUL";
  // urtstrGradient = "http://localhost:7005/GradientInfra?RouteString=SPJ-BLRI-UJP-NAZJ-BSRA-DSS-STJT-BCA-MPNH-TGA-BUJ-BJU-GHX-DKGS-BTPH-RJO-HTZU-RDUM-JLPH-BRYA-GGSY-DMRX-DJS-MKB-LKR-KIUL";
  // urtstr1 = "http://localhost:7005/RollDiagram?RouteString=SPJ-BLRI-UJP-NAZJ-BSRA-DSS-STJT-BCA-MPNH-TGA-BUJ-BJU-GHX-DKGS-BTPH-RJO-HTZU-RDUM-JLPH-BRYA-GGSY-DMRX-DJS-MKB-LKR-KIUL";

  urtstr = "http://localhost:7005/RollDiagram?RouteString=DBRG-CKW-LHL-DKM-CHB-PNT-NTSK-TSK-SPGN-CGF-BDT-DJG-NHK-BTZ-NAM-BFD-BRNR-SPK-LPTA-BOJ-SFR-LXA-MUGN-SLGR-NZR-MZA-NMT-AGI-SLX-LH-NCH-MXN-KQY-TTB-CFG-KXL-FKG-OTN-JMI-BHGN-BXP-SZR-NJN-CJA-BXJ-KHKT-DMV-RXRX-RXR-DSR-DLDE-DPU-NLN-LCT-BRLF-LMG-PKB-LKG-HWX-LKA-DHRY-HJI-JGJN-JMK-KWM-LPN-CPK-TGE-DML-SNBR-AJRE-JID-BRHU-KKET-TTLA-DGU-PNB-TKC-PHI-NNGE-NMY-NGC-GHY-KYQ-AZA-MRZA-CGON-BMGN-BOKO-SNCA-DPRA-RGJI-AMGA-DDNI-KRNI-GLPT-PNVT-JPZ-AYU-MZQ-NBQ-NBQY-DTX-BSGN-SLKX-KOJ-FKM-CROA-GOGH-SRPB-JOQ-KAMG-SMTA-NOQ-NBS-NCB-CAPG-MHBA-NYRH-JDGP-NCBD-BPV-MYGD-YLSC-JPE-RQJ-BLK-ABFC-NJP-RNI-NJB-CAT-DMZ-TMH-MXJ-AUB-GEOR-GIL-PJP-KNE-THED-HWR-KKA-SJKL-DLK-TETA-AHL-SUD-SJGM-BOE-MFA-BWPB-AZR-KMPH-KWE-BAHN-KDPR-HCR-MQG-BKRD-MFZ-SM-SRPU-KMRJ-MBC-EKI-ADF-OMLF-MLDT-GZM-JMQ-KTJ-CMX-NFK-TDLE-BDBS-BDAG-BDLC-GMAN-KLP-TBB-PKR-NGF-RJG-BSBR-MRR-CTR-NHT-SDLE-RPH-TPF-MLV-GHLE-SNT-BSLE-AMP-KPLE-PNE-BHP-BDH-PCQ-GKH-NRX-BPS-JTL-KAN-TIT-BWN-GRP-SKG-PRAE-CHC-MSAE-NBAE-JRAE-JPQ-GRAE-HIH-CRAE-SHBC-DNHL-BMAE-PBZ-CDAE-MDSE-KQU-BLAE-MBE-BRPA-BPAE-JOX-GBRA-DKAE-CCLW-BTNG-BALT-BKNM-MRFO-ADL-SEL-ABB-NALR-BVA-CGA-FLR-ULB-BSBP-KGY-BZN-GGTA-DTE-KIG-MCA-NDGJ-BOP-NPMR-PKEO-PKU-KHAI-HAUR-RDU-DUAN-BCK-SMCK-MPD-JPR-KGP-HIJ-BPE-NYA-VKD-BLDA-NSI-DNT-AGV-LXD-JER-RGT-ARD-BTS-NMBR-ROP-HIP-TKPL-BLS-NGRD-KHF-PNPN-BNBR-SORO-SZZ-MKO-RNTL-RLJC-BHC-BUDR-KPLD-KED-MZZ-DLPT-BTV-KRIH-JJKR-JKPR-BRMI-JEN-NGMP-HDS-DNM-BRTG-BYY-SJDR-KIS-NRG-MACR-KNPR-CTC-KTJI-GBK-BRAG-BBSN-PTAB-MCS-BNBH-BBS-LGTR-RTN-KUR-ARGL-KPXR-DLMH-TAP-GLBA-NKP-BSDP-MKTP-KAPG-KUU-GNGD-SLZ-BALU-CLKA-KLJI-KIT-RBA-HMA-GAM-CAPC-CAP-NRSP-JNP-BAM-GTA-SLRD-IPM-JPI-SPT-BAV-MMS-SUDV-PSA-PUN-RMZ-NWP-DGB-KBM-HCM-TIU-ULM-CHE-DUSI-PDU-SGDM-BTVA-CPP-GVI-NML-VZM-KUK-ALM-KPL-KTV-PDT-SCMN-SCM-GPT-MIPM-VSKP-MIPM-GPT-DVD-THY-AKP-KSK-BVM-NASP-YLM-REG-NRP-GLU-TUNI-HVM-TMPM-ANV-RVD-DGDG-GLP-PAP-SLO-MPU-BVL-BBPM-APT-DWP-KYM-RJY-KVR-PSDA-CU-BMGM-NDD-NBM-TDD-BPY-VGT-CEL-PUA-BMD-DEL-EE-PRH-VAT-NZD-VRVL-TOU-PAVP-GWM-MBD-GALA-VNEC-BZA-KCC-KAQ-PVD-CLVR-DIG-KLX-TEL-TSR-MDKU-NDO-MCVM-APL-BPP-SPF-IPPM-CLX-JAQ-VTM-KPLL-KVDU-CJM-UGD-RPRL-ANB-KRV-OGL-SDM-TNR-SKM-UPD-TTU-KVZ-SVPM-BTTR-AXR-TMC-KJJ-PGU-NLR-NLS-VDE-VKT-KMLP-MBL-GDR-KQA-VDD-NDZ-VKI-YAL-YLK-AKY-KHT-RCG-YPD-RU-PUDI-SVF-TDK-PUT-VGA-EKM-NG-VKZ-POI-TRT-AJJN-MLPM-CTRE-AVN-MDVE-SHU-TUG-WJR-MCN-THL-SVUR-KPD-LTI-VJ-KVN-GYM-MEH-VLT-MPI-PCKM-AB-VGM-VN-KDY-JTJ-JTJB-TPT-KEY-KNNT-SLY-DST-DPI-MAP-TNGR-BDY-BQI-LCR-DSPT-TNT-KPPR-MGSJ-SA-VRPD-DC-MVPM-SGE-ANU-CV-ED-TPM-PY-IGR-VZ-UKL-TUP-VNJ-SNO-SUU-IGU-SHI-PLMD-CBF-CBE-PTJ-MDKI-ETMD-WRA-CLMD-KJKD-KTKU-PGT-PLL-MNY-LDY-PLPM-OTP-MNUR-SRRA-SRRB-VTK-MUC-WKI-MGK-PNQ-TCR-OLR-PUK-NYI-IJK-CKI-DINR-KRAN-KUC-AFK-CWR-AWY-KLMR-IPL-ERN-ERSC-ERSD-TRTR-KFE-MNTT-KPTM-PVRD-VARD-KDTY-KRPP-ETM-KFQ-KTYM-CGV-CGY-TRVL-CNGR-CYN-MVLK-KYJ-OCR-KPY-STKT-MQO-PRND-QLN-IRP-MYY-PVU-KFI-EVA-VAK-AMY-KVU-CRY-PGZ-MQU-KXP-KZK-VELI-KCVL-TVP-TVC-NEM-BRAM-NYY-AMVA-DAVM-PASA-KZTW-KZT-PYD-ERL-VRLR-NJT-NCJ-CAPE";






  myArray = ['apple', 'apple1'];


  datatest = [
    {
      "State": "Uttar Pradesh",
      "Capital": "Lucknow"
    },
    {
      "State": "Uttar Pradesh1",
      "Capital": "Lucknow"
    },
    {
      "State": "Uttar Pradesh2",
      "Capital": "Lucknow"
    },
    {
      "State": "Uttar Pradesh3",
      "Capital": "Lucknow"
    }

  ]

  datatest1 = [
    {
      "State": "Uttar Pradesh",
      "Capital": "Lucknow"
    }
  ]




  constructor(props) {

    console.warn("constructor");
    super(props);
    this.state = {
      users: null,
      Psrdata: null,
      Gradientdata: null,
      Curvaturedata: null,
      Rolldiagramdata: null,

      routedistance: null,
      pointlist: null,
      showInputComponent: false,
      rotateAngle: "rotate(0, 500 500)",
      dataFromChild: '',
      data:"testdataaa"


    }


  }



  toggleInputComponent = () => {
    this.setState((prevState) => ({
      showInputComponent: !prevState.showInputComponent,
    }));
  };



  componentDidMount() {


    this.fetchData();

    console.warn("1----componentDidMount");


    //alert("before");

    fetch(this.urtstr1).then((resp => {


      resp.json().then((result) => {


        //  console.warn(result.data[0].stationCode);
        this.setState({ users: result })
        console.warn("1----          Rolldiaram");
        this.setState({ routedistance: result[result.length - 1].cumulativeDistance });
        this.routedistance = result[result.length - 1].cumulativeDistance;
       // alert("distance ======="+this.routedistance);

        //this.setState((state)=>{return {users:result.data}});

      }
      )
    }
    ))
   // alert("after");
    fetch(this.urtstrPsr).then((resp => {

      resp.json().then((result1) => {

        this.setState({ Psrdata: result1 })

        console.warn("1----urtstrPsr");
        result1.forEach(psr => {

          this.polygonpoints += ",";

          this.polygonpoints += this.offsetX + psr.cum_DISTANCE * this.distanceScale;
          this.polygonpoints += ",";
          this.polygonpoints += this.offsetYPSR - psr.sctnspeed;
          this.polygonpoints += ",";
          this.polygonpoints += this.offsetX + (psr.distance === null ? (psr.cum_DISTANCE + 0) : (psr.cum_DISTANCE + psr.distance)) * this.distanceScale;
          this.polygonpoints += ",";
          this.polygonpoints += this.offsetYPSR - psr.sctnspeed;




        });
        this.polygonpoints += ("," + this.offsetX + "," + this.offsetYPSR);
        //this.setState({pointlist:this.polygonpoints})

      }
      )
    }
    ))

    fetch(this.urtstrGradient).then((resp => {

      resp.json().then((gradedata) => {
        this.setState({ Gradientdata: gradedata })
        this.currentLevel = this.offsetYGrade - 100;


        //const aProducts = result3.filter(product => product.sttncode.startsWith('A'));.
        // const abProducts = gradedata.filter(product => product.sttncode.startsWith('S') || product.sttncode.startsWith('L'));
        console.warn("1----urtstrGradient");


        this.currentLevel = this.offsetYGrade - 100;
        this.gradePolygonPoints += "," + this.offsetX + "," + this.currentLevel;



        gradedata.forEach(grade => {
          if (grade.grade_SelectedRoute_FromKm !== null) {

            this.currgradepoints = ",";

            this.currgradepoints += (this.offsetX + Math.min(Math.min(grade.grade_SelectedRoute_FromKm, this.state.routedistance), grade.grade_SelectedRoute_UptoKm) * this.distanceScale);
            this.currgradepoints += ",";
            this.currgradepoints += this.currentLevel;
            this.currgradepoints += ",";
            this.currgradepoints += (this.offsetX + Math.max(Math.min(grade.grade_SelectedRoute_UptoKm, this.state.routedistance), grade.grade_SelectedRoute_FromKm) * this.distanceScale);
            this.currgradepoints += ",";
            this.currgradepoints += (this.currentLevel - (grade.grade_Type === "LEVEL" ? 0 : (grade.grade_Type === "RISE" ? 1 : -1)) * (grade.grade_Value * 0.01));

            this.currentLevel = this.currentLevel - (grade.grade_Type === "LEVEL" ? 0 : (grade.grade_Type === "RISE" ? 1 : -1)) * (grade.grade_Value * 0.01);


            this.gradePolygonPoints += this.currgradepoints;
            this.testvar = (this.offsetX + Math.max(Math.min(grade.grade_SelectedRoute_UptoKm, this.state.routedistance), grade.grade_SelectedRoute_FromKm) * this.distanceScale);

          }


          //this.gradetestpoints+=grade.grade_SelectedRoute_UptoKm + ",";

          //- (grade.grade_SelectedRoute_UptoKm - grade.grade_SelectedRoute_FromKm) * (grade.grade_Type==="LEVEL"?0:(grade.grade_Type==="RISE"?1:-1)) * grade.grade_Value;

          // this.currentLevel =  this.currentLevel - (grade.grade_SelectedRoute_UptoKm - grade.grade_SelectedRoute_FromKm) * (grade.grade_Type==="LEVEL"?0:(grade.grade_Type==="RISE"?1:-1)) * grade.grade_Value;




        }



        );
        this.gradePolygonPoints += "," + this.testvar + "," + this.offsetYGrade;

        //this.gradePolygonPoints +=this.offsetX+","+this.offsetYGrade;






      }
      )
    }
    ))

    fetch(this.urtstrCurvature).then((resp => {

      resp.json().then((CurveData) => {
        this.setState({ Curvaturedata: CurveData })

        console.warn("1----urtstrCurvature");
        CurveData.forEach(curv => {

          if (curv.curve_SelectedRoute_FromKm !== null && curv.curve_SelectedRoute_UptoKm !== null) {
            this.currCurvePoints = ",";
            this.currCurvePoints += this.offsetX + Math.min(Math.min(parseFloat(curv.curve_SelectedRoute_FromKm), parseFloat(curv.curve_SelectedRoute_UptoKm)), this.state.routedistance) * this.distanceScale;
            this.currCurvePoints += ",";
            this.currCurvePoints += this.offsetYCurvature;
            this.currCurvePoints += ",";
            this.currCurvePoints += this.offsetX + Math.min(Math.min(parseFloat(curv.curve_SelectedRoute_FromKm), parseFloat(curv.curve_SelectedRoute_UptoKm)), this.state.routedistance) * this.distanceScale;
            this.currCurvePoints += ",";
            this.currCurvePoints += parseFloat(this.offsetYCurvature) - parseFloat(curv.curve_AngleInDegree) * 20;
            this.currCurvePoints += ",";
            this.currCurvePoints += this.offsetX + Math.min(Math.max(parseFloat(curv.curve_SelectedRoute_UptoKm), parseFloat(curv.curve_SelectedRoute_FromKm)), this.state.routedistance) * this.distanceScale;
            this.currCurvePoints += ",";
            this.currCurvePoints += parseFloat(this.offsetYCurvature) - parseFloat(curv.curve_AngleInDegree) * 20;
            this.currCurvePoints += ",";
            this.currCurvePoints += this.offsetX + Math.min(Math.max(parseFloat(curv.curve_SelectedRoute_FromKm), parseFloat(curv.curve_SelectedRoute_UptoKm)), this.state.routedistance) * this.distanceScale;
            this.currCurvePoints += ",";
            this.currCurvePoints += this.offsetYCurvature;

            this.curvaturepolygonpoints += this.currCurvePoints;
          }



          if (curv.curve_SelectedRoute_UptoKm === "87.72") {

            //console.warn("curvaute------------------------------------------------------------"); 

          }

        }

        );

        //this.curvaturepolygonpints += "," + (parseFloat(this.offsetX) + parseFloat(this.state.routedistance) * parseFloat(this.distanceScale)) + "," + parseFloat(this.offsetYCurvature);





      }
      )
    }
    ))




  }




  componentDidUpdate(prevProps, prevState) {




    if (this.state.users != null && this.state.Gradientdata != null && this.state.Psrdata != null && this.state.Curvaturedata != null) {



    }
    // code to be executed after the component is updated
  }

  handleDataFromChild = (data) => {

    alert("data from child"+data);
    alert(data.trailweight);
    alert(JSON.stringify(data));
    this.setState({ dataFromChild: data });
  };


  handleClick = () => {
    // Call the JavaScript function from the other file

    alert("1");
    SimulateWithParameter();
  };


  handleDataChange = (newData) => {
    this.setState({ data: newData });
  };




  render() {

    console.warn("render");




    return (
      <div className="App">

        {/* <table align='center'>
          <tr>
            <td align='left'> <button onClick={this.exportToExcel}>Export Route Data</button> </td>
            <td align='right'> <button onClick={this.toggleInputComponent}> Set Simulation Parameter</button></td>
            <td align='center'> <button onMouseDown={this.exportToExcel1} onMouseUp={this.exportToExcel2}>Print Route Diagram</button> </td>
            <td align='center'> <button onClick={this.handleClick}>Click me</button></td>
          </tr>
        </table>


        <MyContext.Provider value={{ data: this.state.data, handleDataChange: this.handleDataChange }}>

        {this.state.showInputComponent && <InputComponent name={this.handleDataFromChild} />}
          
        <InputComponent />
        <AnotherChildComponent />  
        </MyContext.Provider>
        <ParentComponent /> */}



        <ChildComponent/>

    




        {/* { <ComboComponent/> } */}


        {/* <h1>-----------METHODS-------------------------------- AS PROPS-------------</h1>
        <h1>-----------METHODS-------------------------------- AS PROPS-------------</h1> */}

        {/* <ParentComponent /> */}


        <svg xmlns="http://www.w3.org/2000/svg" x="20" y="20" height="1400px" width={this.offsetX + this.routedistance * this.distanceScale + 200 * this.offsetX}>
          <g id="g11" fill="grey" transform={this.state.rotateAngle} >




            <p>
              Edit <code>src/App.js</code> and save to reload.;

            </p>


            {
              this.myArray.map((val121, kk) =>

                <g>



                  <polygon
                    points={this.polygonpoints} stroke="lightgreen"
                    stroke-width="2.5"
                    fill="lightgreen"
                    strokeLinejoin="round" >
                    <title>{this.polygonpoints}</title>
                  </polygon>

                  <polygon
                    points={this.gradePolygonPoints} stroke="lightgray"
                    stroke-width="2.5"
                    fill="lightgray"
                    strokeLinejoin="round" >
                    <title>{this.gradePolygonPoints}</title>
                  </polygon>


                  <polyline
                    points={this.curvaturepolygonpoints} stroke="red"
                    stroke-width="2.5"
                    fill="transparent"
                    strokeLinejoin="round" >
                    <title>{this.currCurvePoints}</title>
                  </polyline>





                  {
                    this.Speeds.map((spd, ss) =>
                      <g>

                        <line
                          x1={this.offsetX}
                          y1={this.offsetYPSR - ss * 10}
                          x2={this.offsetX + this.state.routedistance * this.distanceScale}
                          y2={this.offsetYPSR - ss * 10}
                          stroke={ss % 3 === 0 ? "red" : "gray"}
                          stroke-width={ss % 3 === 0 ? "0.50" : "0.25"}>
                        </line>
                        <text textAnchor="end" fill={ss % 3 === 0 ? "red" : "gray"} fontSize={8} x={this.offsetX - 10} y={this.offsetYPSR - ss * 10 + 2.5}>{ss * 10} Kmph</text>
                        <text textAnchor="start" fill={ss % 3 === 0 ? "red" : "gray"} fontSize={8} x={this.offsetX + this.state.routedistance * this.distanceScale + 10} y={this.offsetYPSR - ss * 10 + 2.5}>{ss * 10} Kmph</text>
                      </g>

                    )


                  }





                  {

                    this.state.Psrdata ?
                      this.state.Psrdata.map((psr, in111) =>
                        <g>


                          if (psr.psr_SelectedRoute_FromKm != null)
                          {
                            <rect
                              x={this.offsetX + psr.psr_SelectedRoute_FromKm * this.distanceScale}
                              y={this.offsetYPSR - psr.sctnspeed}
                              width={(psr.psr_SelectedRoute_UptoKm - psr.psr_SelectedRoute_FromKm) * this.distanceScale}
                              height={(psr.sctnspeed - psr.psr_PSpeedKmph)}
                              stroke="yellow"
                              stroke-width="2.5"
                              fill="yellow"
                              zIndex="100"
                            >
                              <title> From {psr.psr_SelectedRoute_FromKm} To {psr.psr_SelectedRoute_UptoKm}</title>
                            </rect>
                          }

                        </g>
                      ) : null
                  }




                  {
                    this.state.users ?
                      this.state.users.map((val, i) =>
                        <g >
                          <p> {i} {val.stationCode} "hello"   {this.distanceScale}  </p>




                          <text key={val.stationCode}
                            render-order="5"
                            x={this.offsetX + val.cumulativeDistance * this.distanceScale}
                            y={this.offsetY - 40}
                            fontWeight="bold"
                            fontSize="18.0"
                            alignmentBaseline="middle"
                            textAnchor="middle"
                            fill="red"
                            fontFamily="Times New Roman"
                          >
                            {val.stationCode}
                          </text>

                          <text key={val.stationClass}
                            render-order="5"
                            x={this.offsetX + val.cumulativeDistance * this.distanceScale}
                            y={this.offsetY - 25}
                            fontWeight="bold"
                            fontSize="10.0"
                            alignmentBaseline="middle"
                            textAnchor="middle"
                            fill="gray"
                            fontFamily="Times New Roman"
                          >
                            '{val.stationClass}'
                          </text>

                          <text key={val.className}
                            render-order="5"
                            x={this.offsetX + val.cumulativeDistance * this.distanceScale}
                            y={this.offsetY}
                            fontWeight="bold"
                            fontSize="12.0"
                            alignmentBaseline="middle"
                            textAnchor="middle"
                            fill="maroon"
                            fontFamily="Times New Roman"
                          >
                            {val.stationName}
                          </text>

                          <text key={val.interDistance}
                            render-order="5"
                            x={this.offsetX + (val.cumulativeDistance + (val.interDistance * 0.5)) * this.distanceScale}
                            y={this.offsetY - 10}
                            fontWeight="bold"
                            fontSize="12.0"
                            alignmentBaseline="middle"
                            textAnchor="middle"
                            fill="blue"
                            fontFamily="Times New Roman"
                          >
                            {val.interDistance} Km
                          </text>



                          {

                            val.platformList.map((pf, j) =>

                              <g>
                                <p> {i} {val.stationCode} "hello"   {this.linecolor1}  </p>




                                <line key={pf.pfname + pf.lineNumber}
                                  x1={this.offsetX + val.cumulativeDistance * this.distanceScale - this.lineWidth * 0.5}
                                  y1={this.offsetY + (pf.verticalposition === 'U' ? (pf.lineNumber * this.lineGapVertical - this.lineGapVertical * 0.25) : (pf.lineNumber * this.lineGapVertical + this.lineGapVertical * 0.25))}
                                  x2={this.offsetX + val.cumulativeDistance * this.distanceScale + this.lineWidth * 0.5}
                                  y2={this.offsetY + (pf.verticalposition === 'U' ? (pf.lineNumber * this.lineGapVertical - this.lineGapVertical * 0.25) : (pf.lineNumber * this.lineGapVertical + this.lineGapVertical * 0.25))}
                                  strokeWidth={this.lineGapVertical * 0.5}
                                  stroke="gray"
                                  strokeLinejoin="round"
                                >
                                </line>

                                <text key={val.interDistance}
                                  renderOrder="5"
                                  x={(pf.verticalposition === 'U' ? (this.offsetX + val.cumulativeDistance * this.distanceScale - this.lineWidth * 0.5 + 10.0) : (this.offsetX + val.cumulativeDistance * this.distanceScale + this.lineWidth * 0.5 - 15.0))}
                                  y={this.offsetY + (pf.verticalposition === 'U' ? (pf.lineNumber * this.lineGapVertical - this.lineGapVertical * 0.25) : (pf.lineNumber * this.lineGapVertical + this.lineGapVertical * 0.25))}
                                  fontWeight="bold"
                                  fontSize="10.0"
                                  alignmentBaseline="middle"
                                  textAnchor="middle"
                                  fill="white"
                                  fontFamily="Times New Roman"
                                >
                                  {pf.pfname}
                                </text>

                              </g>
                            )

                          }
                          {

                            val.stationLineList.map((sl, m) =>
                              <g>
                                <line key={sl.lineName}
                                  x1={this.offsetX + val.cumulativeDistance * this.distanceScale - this.lineWidth * .5}
                                  y1={this.offsetY + sl.lineSeq * this.lineGapVertical}
                                  x2={this.offsetX + val.cumulativeDistance * this.distanceScale + this.lineWidth * .5}
                                  y2={this.offsetY + sl.lineSeq * this.lineGapVertical}
                                  strokeWidth="2"
                                  stroke="red"
                                  strokeLinejoin="round"
                                >
                                </line>

                                <line key={sl.lineName}
                                  x1={this.offsetX + val.cumulativeDistance * this.distanceScale - this.lineWidth * .25}
                                  y1={this.offsetY + sl.lineSeq * this.lineGapVertical}
                                  x2={this.offsetX + val.cumulativeDistance * this.distanceScale + this.lineWidth * .25}
                                  y2={this.offsetY + sl.lineSeq * this.lineGapVertical}
                                  strokeWidth="15"
                                  stroke="red"
                                  strokeLinejoin="round"
                                >
                                </line>

                                <text key={val.stationName}
                                  render-order="5"
                                  x={this.offsetX + val.cumulativeDistance * this.distanceScale}
                                  y={this.offsetY + sl.lineSeq * this.lineGapVertical}
                                  fontWeight="bold"
                                  fontSize="10.0"
                                  alignmentBaseline="middle"
                                  textAnchor="middle"
                                  fill="white"
                                  fontFamily="Times New Roman"
                                >
                                  {sl.lineName}
                                </text>
                              </g>
                            )
                          }

                          {val.blockSectionLineList.map((bl, k) =>

                            <g>

                              <line key={bl.lineName + val.cumulativeDistance}
                                x1={this.offsetX + val.cumulativeDistance * this.distanceScale + 100.0}
                                y1={this.offsetY + this.lineGapVertical + bl.lineSeq * this.lineGapVertical}
                                x2={this.offsetX + (val.cumulativeDistance + val.interDistance) * this.distanceScale - 100.0}
                                y2={this.offsetY + this.lineGapVertical + bl.lineSeq * this.lineGapVertical}
                                strokeWidth="2"
                                stroke={(bl.traction === 'E' ? 'blue' : 'red')}
                                strokeDasharray={(bl.sysOfWorking === 'AB' ? ('25 0') : ('25 5'))}
                                strokeLinejoin="round"
                              >
                              </line>

                            </g>

                          )
                          }


                          {val.prevConnectionList.map((pcn, m) =>

                            <g>

                              <defs>
                                <marker id="direction" viewBox="0 0 10 10" refX="40" refY="5"
                                  markerUnits="strokeWidth" markerWidth="3" markerHeight="3"
                                  orient="auto">
                                  <path d="M 0 0 L 10 5 L 0 10 z" fill={(pcn.sendrecieveFlag === 'S' ? 'blue' : 'red')} stroke={pcn.sendrecieveFlag === 'S' ? 'blue' : 'red'} />
                                  fill={(pcn.sendrecieveFlag === 'S' ? 'blue' : 'red')} [attr.stroke]="ncn.sendrecieveFlag=='S'?'blue':'red'" render-order="5"
                                </marker>
                              </defs>

                              <line
                                x1={(pcn.sendrecieveFlag === 'S' ? (this.offsetX + val.cumulativeDistance * this.distanceScale - this.lineWidth * 0.5) : (this.offsetX + val.cumulativeDistance * this.distanceScale - (this.lineWidth * 0.5 + this.connectionGap)))}
                                y1={(pcn.sendrecieveFlag === 'S' ? (this.offsetY + pcn.stationLine * this.lineGapVertical) : (this.offsetY + this.lineGapVertical + pcn.blockSectionLine * this.lineGapVertical))}
                                x2={(pcn.sendrecieveFlag === 'S' ? (this.offsetX + val.cumulativeDistance * this.distanceScale - (this.lineWidth * 0.5 + this.connectionGap)) : (this.offsetX + val.cumulativeDistance * this.distanceScale - this.lineWidth * 0.5))}
                                y2={(pcn.sendrecieveFlag === 'S' ? (this.offsetY + this.lineGapVertical + pcn.blockSectionLine * this.lineGapVertical) : (this.offsetY + pcn.stationLine * this.lineGapVertical))}
                                stroke="red" stroke-width="2.5"
                                stroke-linejoin="round"
                                marker-end="url(#direction)"
                              >
                              </line>

                            </g>

                          )
                          }

                          {

                            val.nextConnectionList.map((ncn, l) =>

                              <g>

                                <defs>
                                  <marker id="direction" viewBox="0 0 10 10" refX="40" refY="5"
                                    markerUnits="strokeWidth" markerWidth="3" markerHeight="3"
                                    orient="auto">
                                    <path d="M 0 0 L 10 5 L 0 10 z" fill={(ncn.sendrecieveFlag === 'S' ? 'blue' : 'red')} stroke={ncn.sendrecieveFlag === 'S' ? 'blue' : 'red'} />
                                    // eslint-disable-next-line react/no-unescaped-entities
                                    fill={(ncn.sendrecieveFlag === 'S' ? 'blue' : 'red')} [attr.stroke]="ncn.sendrecieveFlag=='S'?'blue':'red'" render-order="5"
                                  </marker>
                                </defs>

                                <line
                                  x1={(ncn.sendrecieveFlag === 'S' ? (this.offsetX + val.cumulativeDistance * this.distanceScale + this.lineWidth * .5) : (this.offsetX + val.cumulativeDistance * this.distanceScale + this.lineWidth * .5 + this.connectionGap))}
                                  y1={(ncn.sendrecieveFlag === 'S' ? (this.offsetY + ncn.stationLine * this.lineGapVertical) : (this.offsetY + this.lineGapVertical + ncn.blockSectionLine * this.lineGapVertical))}
                                  x2={(ncn.sendrecieveFlag === 'S' ? (this.offsetX + val.cumulativeDistance * this.distanceScale + this.lineWidth * .5 + this.connectionGap) : (this.offsetX + val.cumulativeDistance * this.distanceScale + this.lineWidth * .5))}
                                  y2={(ncn.sendrecieveFlag === 'S' ? (this.offsetY + this.lineGapVertical + ncn.blockSectionLine * this.lineGapVertical) : (this.offsetY + ncn.stationLine * this.lineGapVertical))}
                                  stroke="red" stroke-width="2.5"
                                  stroke-linejoin="round"
                                  marker-end="url(#direction)"
                                >
                                </line>

                              </g>

                            )

                          }






                        </g>

                      )
                      : null



                  }

                </g>)
            }


          </g>
        </svg>




      </div>
    )
  }
}

// function App() {
//   return (
//     <div className="App">
//       <header className="App-header">
//         <img src={logo} className="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.js</code> and save to reload.
//         </p>
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React
//         </a>
//       </header>
//     </div>
//   );
// }



export default App;
