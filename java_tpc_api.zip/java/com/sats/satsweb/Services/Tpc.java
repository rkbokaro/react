package com.sats.satsweb.Services;

import java.util.ArrayList;
import java.util.List;

import com.sats.satsweb.Model.Loco;
import com.sats.satsweb.Model.Stock;

public class Tpc {


 public static double gravity = 9.81;


 public static int BrakingDistance(double currentSpeed, String currentSpeedUnit, double targetSpeed, String targetSpeedUnit, double decelerationMPSS) {
    if (currentSpeedUnit.equals("KMPH")) {
        currentSpeed = currentSpeed / 3.6;
    }
    if (targetSpeedUnit.equals("KMPH")) {
        targetSpeed = targetSpeed / 3.6;
    }

    int stopDistance = 0;

    double brakingTime = (currentSpeed - targetSpeed) / decelerationMPSS;

    stopDistance = (int) Math.ceil((currentSpeed + targetSpeed) * 0.5 * brakingTime);

    return stopDistance;
}


        public static double ResistanceCurve(double CurveAngle, double TrainMass)
        {
            double Resistance = 0;
            if (CurveAngle != 0)
            {
                Resistance = (0.4 * CurveAngle);
            }
            return Resistance * gravity * TrainMass * 0.001;
        }
        public static double ResistanceGradient(double Grade, double TrainMass)
        {
            double Resistance = 0;
            if (Grade != 0)
            {
                Resistance = (1 / Grade);
            }
            return Resistance * gravity * TrainMass * 0.001;
        }

        public static double TractiveEffort(double Speed, String speedUnit, String Loco, int numberOfLoco) {
    double TE = 0;
    String type = "Standard";

    if (speedUnit.equals("MPS")) {
        Speed = Speed * 3.6;
    }

            if (Loco == "WAG-9")
            {
                if (type == "Standard")
                {
                    if (Speed >= 0 && Speed <= 15)
                        TE = 460;
                    else if (Speed > 15 && Speed <= 36)
                        TE = ((-0.476) * Speed) + 467.14;
                    else if (Speed > 36 && Speed <= 100)
                        TE = 4500 * 3.6 / Speed;
                    else if (Speed > 100 && Speed <= 110)
                        TE = 162 - (162 * (Speed - 100) / (110 - 100));
                    else
                        TE = 0;
                }
                else if (type == "Board")
                {
                    if (Speed >= 0 && Speed < 10)
                        TE = 460 - Speed * (460 - 325) / 10.0;
                    else if (Speed >= 10 && Speed < 49.84)
                        TE = 325.0;
                    else if (Speed > 36 && Speed <= 100)
                        TE = 4500 * 3.6 / Speed;
                    else if (Speed > 100 && Speed <= 110)
                        TE = 162 - (162 * (Speed - 100) / (110 - 100));
                    else
                        TE = 0;
                }
            }
            else if (Loco == "WAG-7")
            {
                if (type == "Standard")
                {

                    if (0 <= Speed && Speed < 21.39)
                        TE = 322.558;
                    else if (21.39 <= Speed && Speed < 51.33)
                        TE = -0.233 * Speed + 327.529;
                    else if (51.33 <= Speed && Speed < 140)
                        TE = 4500 * 3.6 / Speed;
                    else if (140 <= Speed && Speed < 150)
                        TE = -11.571 * Speed + 1735.71;
                    else
                        TE = 0;
                }
            }
            else if (Loco == "WAG-5")
            {
                if (type == "Standard")
                {

                    if (0 <= Speed && Speed < 48)
                        TE = 194.17167;
                    else if (48 <= Speed && Speed < 80)
                        TE = 2588 * 3.6 / Speed;
                    else if (80 <= Speed && Speed < 100)
                        TE = -5.825 * Speed + 582.5;
                    else
                        TE = 0;
                }
            }
            else if (Loco == "WAP-7")
            {
                if (type == "Standard")
                {
                    if (0 <= Speed && Speed < 21.39)
                        TE = 322.558;
                    else if (21.39 <= Speed && Speed < 51.33)
                        TE = -0.233 * Speed + 327.529;
                    else if (51.33 <= Speed && Speed < 140)
                        TE = 4500 * 3.6 / Speed;
                    else if (140 <= Speed && Speed < 150)
                        TE = -11.571 * Speed + 1735.71;
                    else
                        TE = 0;
                }
                else if (type == "Lower")
                {
                    if (0 <= Speed && Speed < 64.8)
                        TE = 250.0;
                    else if (64.8 <= Speed && Speed < 140)
                        TE = 4500 * 3.6 / Speed;
                    else if (140 <= Speed && Speed < 150)
                        TE = -11.57 * Speed + 1735.714;
                    else
                        TE = 0;
                }
                else if (type == "Heigher")
                {
                    if (0 <= Speed && Speed < 19.55)
                        TE = 352.81;
                    else if (19.55 <= Speed && Speed < 46.9)
                        TE = -0.28 * Speed + 358.275;
                    else if (46.9 <= Speed && Speed < 140)
                        TE = 4500 * 3.6 / Speed;
                    else if (140 <= Speed && Speed < 150)
                        TE = -11.57 * Speed + 1735.714;
                    else
                        TE = 0;
                }
                else if (type == "Advanced")
                {
                    if (0 <= Speed && Speed < 19.55)
                        TE = 352.81;
                    else if (19.55 <= Speed && Speed < 46.94)
                        TE = -0.28 * Speed + 358.273;
                    else if (46.94 <= Speed && Speed < 140)
                        TE = 4736 * 3.6 / Speed;
                    else if (140 <= Speed && Speed < 150)
                        TE = -12.178 * Speed + 1826.743;
                    else
                        TE = 0;
                }
                else if (type == "Board")
                {
                    if (0 <= Speed && Speed < 10)
                        TE = 322.558 - Speed * (322.558 - 228) / 10.0;
                    else if (10.0 <= Speed && Speed < 71.05)
                        TE = 228.0;
                    else if (71.05 <= Speed && Speed < 140)
                        TE = 4500 * 3.6 / Speed;
                    else if (140 <= Speed && Speed < 150)
                        TE = -11.571 * Speed + 1735.71;
                    else
                        TE = 0;
                }
            }
           

            else if (Loco == "DESIRO")
            {
                if (0 <= Speed && Speed < 80)
                    TE = 782;
                else if (80 <= Speed && Speed < 160)
                    TE = 17378 * 3.6 / Speed;
                else if (160 <= Speed && Speed < 178)
                    TE = 391.05 - (391.05 * (Speed - 160) / (178 - 160));
                //TE = -3.25 * Speed + 578.5;
                else
                    TE = 0;
            }

           

            else if (Loco == "VNDB")
            {
                if (0 <= Speed && Speed < 41.5)
                    TE = 800;
                else if (41.5 <= Speed && Speed < 160)
                    TE = 9222.3 * 3.6 / Speed;
                else if (160 <= Speed && Speed < 180)
                    TE = 207.50 - (207.50 * (Speed - 160) / (180 - 160));
                //TE = -3.25 * Speed + 578.5;
                else
                    TE = 0;
            }

            else if (Loco == "WAP-5")
            {
                if (type == "Standard")
                {
                    if (0 <= Speed && Speed < 30)
                        TE = 258;
                    else if (30 <= Speed && Speed < 65)
                        TE = -1.029 * Speed + 288.857;
                    else if (65 <= Speed && Speed < 160)
                        TE = 4000 * 3.6 / Speed;
                    else if (160 <= Speed && Speed < 178)
                        TE = -5.0 * Speed + 890;
                    else
                        TE = 0;
                }
                else if (type == "Board")
                {
                    if (0 <= Speed && Speed < 10)
                        TE = 258 - Speed * (258 - 220) / 10.0;
                    else if (10 <= Speed && Speed < 65.45)
                        TE = 220;
                    else if (65.45 <= Speed && Speed < 160)
                        TE = 4000 * 3.6 / Speed;
                    else if (160 <= Speed && Speed < 178)
                        TE = -5.0 * Speed + 890;
                    else
                        TE = 0;
                }
            }

            else if (Loco == "WAP-4")
            {
                if (type == "Standard")
                {
                    if (0 <= Speed && Speed < 72)
                        TE = 186;
                    else if (72 <= Speed && Speed < 120)
                        TE = 3720 * 3.6 / Speed;
                    else if (120 <= Speed && Speed < 130)
                        TE = -11.16 * Speed + 1450.8;
                    else
                        TE = 0;
                }
                else if (type == "Board")
                {
                    if (0 <= Speed && Speed < 10)
                        TE = 186 - Speed * (258 - 220) / 10.0;
                    else if (10 <= Speed && Speed < 65.45)
                        TE = 220;
                    else if (65.45 <= Speed && Speed < 160)
                        TE = 4000 * 3.6 / Speed;
                    else if (160 <= Speed && Speed < 178)
                        TE = -5.0 * Speed + 890;
                    else
                        TE = 0;
                }
            }

            return TE * numberOfLoco;
        }
        public static double BrakingEffort(double Speed, String SpeedUnit, String Loco, int NumberOfLoco)
        {
            double BE = 0;
            double BrakingTractiveRatio = (-260.0 / 460.0);

            if (SpeedUnit == "MPS")
            {
                Speed = Speed * 3.6;
            }

            if (Loco == "WAG-9")
            {
                if (Speed >= 0 && Speed <= 10)
                {
                    BE = (-260.0 / 10.0) * Speed;
                }
                else if (Speed > 10 && Speed <= 15)
                {
                    BE = (BrakingTractiveRatio) * (460);
                }
                else if (Speed > 15 && Speed <= 36)
                {
                    BE = (BrakingTractiveRatio) * (((-0.476) * Speed) + 467.14);
                }
                else if (Speed > 36)
                {
                    BE = (BrakingTractiveRatio) * (4500 * 3.6 / Speed);
                }
                else
                {
                    BE = 0;
                }
            }
            return BE * NumberOfLoco;
        }
        public static double ResistanceLoco(double Speed, String SpeedUnit, String Loco, int NumberOfLoco)
        {
            int NoOfAaxels;
            double AdhesiveMass =0;
            double Resistance = 0;
            double StartingResistance = 6.0;
            double ResistanceAtRollingSpeed = 0;
            double RollingSpeedKMPH = 3.6;

            if (SpeedUnit == "MPS")
            {
                Speed = Speed * 3.6;
            }

            if (Loco == "WAG-5")
            {
                NoOfAaxels = 6;
                AdhesiveMass = 119.0;
                if (Speed <= RollingSpeedKMPH)
                {
                    ResistanceAtRollingSpeed = (0.057 / AdhesiveMass) * RollingSpeedKMPH * RollingSpeedKMPH + 0.00933 * RollingSpeedKMPH + (0.647 + (13.17 * NoOfAaxels) / AdhesiveMass);
                    Resistance = StartingResistance + ((ResistanceAtRollingSpeed - StartingResistance) / (RollingSpeedKMPH)) * Speed;
                }
                else
                {
                    Resistance = (0.057 / AdhesiveMass) * Speed * Speed + 0.00933 * Speed + (0.647 + (13.17 * NoOfAaxels) / AdhesiveMass);
                }
            }
            else if (Loco == "WAG-7")
            {
                NoOfAaxels = 6;
                AdhesiveMass = 123.0;
                if (Speed <= RollingSpeedKMPH)
                {
                    ResistanceAtRollingSpeed = (0.057 / AdhesiveMass) * RollingSpeedKMPH * RollingSpeedKMPH + 0.00933 * RollingSpeedKMPH + (0.647 + (13.17 * NoOfAaxels) / AdhesiveMass);
                    Resistance = StartingResistance + ((ResistanceAtRollingSpeed - StartingResistance) / (RollingSpeedKMPH)) * Speed;
                }
                else
                {
                    Resistance = (0.057 / AdhesiveMass) * Speed * Speed + 0.00933 * Speed + (0.647 + (13.17 * NoOfAaxels) / AdhesiveMass);
                }
            }
            else if (Loco == "WAG-9")
            {
                NoOfAaxels = 6;
                AdhesiveMass = 123.0;
                if (Speed <= RollingSpeedKMPH)
                {
                    ResistanceAtRollingSpeed = (0.057 / AdhesiveMass) * RollingSpeedKMPH * RollingSpeedKMPH + 0.00933 * RollingSpeedKMPH + (0.647 + (13.17 * NoOfAaxels) / AdhesiveMass);
                    Resistance = StartingResistance + ((ResistanceAtRollingSpeed - StartingResistance) / (RollingSpeedKMPH)) * Speed;
                }
                else
                {
                    Resistance = (0.057 / AdhesiveMass) * Speed * Speed + 0.00933 * Speed + (0.647 + (13.17 * NoOfAaxels) / AdhesiveMass);
                }
            }
            else if (Loco == "WAP-7")
            {
                NoOfAaxels = 6;
                AdhesiveMass = 123.0;

                if (Speed <= RollingSpeedKMPH)
                {
                    ResistanceAtRollingSpeed = (0.057 / AdhesiveMass) * RollingSpeedKMPH * RollingSpeedKMPH + 0.00933 * RollingSpeedKMPH + (0.647 + (13.17 * NoOfAaxels) / AdhesiveMass);
                    Resistance = StartingResistance + ((ResistanceAtRollingSpeed - StartingResistance) / (RollingSpeedKMPH)) * Speed;
                }
                else
                {
                    Resistance = (0.057 / AdhesiveMass) * Speed * Speed + 0.00933 * Speed + (0.647 + (13.17 * NoOfAaxels) / AdhesiveMass);
                }
            }
            else if (Loco == "WAP-5")
            {
                NoOfAaxels = 4;
                AdhesiveMass = 78.0;
                if (Speed <= RollingSpeedKMPH)
                {
                    ResistanceAtRollingSpeed = (0.057 / AdhesiveMass) * RollingSpeedKMPH * RollingSpeedKMPH + 0.00933 * RollingSpeedKMPH + (0.647 + (13.17 * NoOfAaxels) / AdhesiveMass);
                    Resistance = StartingResistance + ((ResistanceAtRollingSpeed - StartingResistance) / (RollingSpeedKMPH)) * Speed;
                }
                else
                {
                    Resistance = (0.057 / AdhesiveMass) * Speed * Speed + 0.00933 * Speed + (0.647 + (13.17 * NoOfAaxels) / AdhesiveMass);
                }
            }
            //else if (Loco == "DESIRO")
            //{
            //    NoOfAaxels = 4;
            //    AdhesiveMass = 162.0;
            //    if (Speed <= RollingSpeedKMPH)
            //    {
            //        ResistanceAtRollingSpeed = (0.057 / AdhesiveMass) * RollingSpeedKMPH * RollingSpeedKMPH + 0.00933 * RollingSpeedKMPH + (0.647 + (13.17 * NoOfAaxels) / AdhesiveMass);
            //        Resistance = StartingResistance + ((ResistanceAtRollingSpeed - StartingResistance) / (RollingSpeedKMPH)) * Speed;
            //    }
            //    else
            //    {
            //        Resistance = (0.057 / AdhesiveMass) * Speed * Speed + 0.00933 * Speed + (0.647 + (13.17 * NoOfAaxels) / AdhesiveMass);
            //    }
            //}
            else if (Loco == "DESIRO")
            {
                NoOfAaxels = 20;
                AdhesiveMass = 966.0;
                //RollingSpeedKMPH = 0;
                //if (Speed <= RollingSpeedKMPH)
                //{
                //    //ResistanceAtRollingSpeed = (0.057 / AdhesiveMass) * RollingSpeedKMPH * RollingSpeedKMPH + 0.00933 * RollingSpeedKMPH + (0.647 + (13.17 * NoOfAaxels) / AdhesiveMass);
                //    ResistanceAtRollingSpeed = ((6.5666 / (3.6 * 3.6)) * RollingSpeedKMPH * RollingSpeedKMPH) + ((51.46 / 3.6) * RollingSpeedKMPH) + (0.0162 * AdhesiveMass * 1000.0);
                //    Resistance = StartingResistance + ((ResistanceAtRollingSpeed - StartingResistance) / ((RollingSpeedKMPH))) * (Speed / 3.6);
                //}
                //else
                //{
                //Resistance = (0.057 / AdhesiveMass) * Speed * Speed + 0.00933 * Speed + (0.647 + (13.17 * NoOfAaxels) / AdhesiveMass);
                Resistance = ((6.5666 / (3.6 * 3.6)) * Speed * Speed) + ((51.46 / 3.6) * Speed) + (0.0162 * AdhesiveMass * 1000.0);
                //}
                return Resistance * NumberOfLoco * 0.001;
            }
            else if (Loco == "VNDB")
            {
                NoOfAaxels = 20;
                AdhesiveMass = 966.0;
                //RollingSpeedKMPH = 0;
                //if (Speed <= RollingSpeedKMPH)
                //{
                //    //ResistanceAtRollingSpeed = (0.057 / AdhesiveMass) * RollingSpeedKMPH * RollingSpeedKMPH + 0.00933 * RollingSpeedKMPH + (0.647 + (13.17 * NoOfAaxels) / AdhesiveMass);
                //    ResistanceAtRollingSpeed = ((6.5666 / (3.6 * 3.6)) * RollingSpeedKMPH * RollingSpeedKMPH) + ((51.46 / 3.6) * RollingSpeedKMPH) + (0.0162 * AdhesiveMass * 1000.0);
                //    Resistance = StartingResistance + ((ResistanceAtRollingSpeed - StartingResistance) / ((RollingSpeedKMPH))) * (Speed / 3.6);
                //}
                //else
                //{
                //Resistance = (0.057 / AdhesiveMass) * Speed * Speed + 0.00933 * Speed + (0.647 + (13.17 * NoOfAaxels) / AdhesiveMass);
                Resistance = ((6.5666 / (3.6 * 3.6)) * Speed * Speed) + ((51.46 / 3.6) * Speed) + (0.0162 * AdhesiveMass * 1000.0);
                //}
                return Resistance * NumberOfLoco * 0.001;
            }

            return Resistance * NumberOfLoco * AdhesiveMass * 0.001;
        }
        public static double ResistanceCoach(double Speed, String SpeedUnit, String Type, double TrailingLoad)
        {
            double Resistance = 0;
            double StartingResistance = 5.0;
            double ResistanceAtRollingSpeed = 0;
            double RollingSpeedKMPH = 3.0;

            if (SpeedUnit == "MPS")
            {
                Speed = Speed * 3.6;
            }

            if (Type == "COACH")
            {
                if (Speed <= RollingSpeedKMPH)
                {
                    ResistanceAtRollingSpeed = 0.000082 * RollingSpeedKMPH * RollingSpeedKMPH + 0.02112 * RollingSpeedKMPH + 0.6855;
                    Resistance = StartingResistance + ((ResistanceAtRollingSpeed - StartingResistance) / (RollingSpeedKMPH)) * Speed;
                }
                else
                {
                    Resistance = 0.000082 * Speed * Speed + 0.02112 * Speed + 0.6855;
                }
            }
            return Resistance * gravity * TrailingLoad * 0.001;
        }
        public static double ResistanceWagon(double Speed, String SpeedUnit, String Type, double TrailingLoad)
        {
            double Resistance = 0;
            double StartingResistance = 4.0;
            double ResistanceAtRollingSpeed = 0;
            double RollingSpeedKMPH = 3.0;

            if (SpeedUnit == "MPS")
            {
                Speed = Speed * 3.6;
            }

            if (Type == "WAGON")
            {
                if (Speed <= RollingSpeedKMPH)
                {
                    ResistanceAtRollingSpeed = 0.000056 * RollingSpeedKMPH * RollingSpeedKMPH + 0.0103 * RollingSpeedKMPH + 0.87;
                    Resistance = StartingResistance + ((ResistanceAtRollingSpeed - StartingResistance) / (RollingSpeedKMPH)) * Speed;
                }
                else
                {
                    Resistance = 0.000056 * Speed * Speed + 0.0103 * Speed + 0.87;
                }
            }
            return Resistance * gravity * TrailingLoad * 0.001;
        }
        public static double ResistanceTrain(String Loco, int NumberOfLoco, double AdhesiveMass, double TrailingLoad,String TrailType, double Speed, String SpeedUnit, double CurveAngle, double GradeValue)
        {
            double Resistance = 0;

            Resistance = ResistanceLoco(Speed,SpeedUnit, Loco, NumberOfLoco)
                         + (TrailType == "COACH" ? ResistanceCoach(Speed, SpeedUnit, "COACH", TrailingLoad) : ResistanceWagon(Speed, SpeedUnit, "WAGON", TrailingLoad))
                         + ResistanceCurve(CurveAngle, NumberOfLoco * AdhesiveMass + TrailingLoad)
                         + ResistanceGradient(GradeValue, NumberOfLoco * AdhesiveMass + TrailingLoad);
            return Resistance;
        }

        public static List<Loco> LocoList = new ArrayList<>();
        public static void PopulateLocoList() {

            LocoList.add(new Loco("VNDB", 78, 25));
            LocoList.add(new Loco("VNDB", 78, 25));
            LocoList.add(new Loco("WAP-4", 113, 19));
            LocoList.add(new Loco("WAP-5", 78, 18));
            LocoList.add(new Loco("WAP-7", 123, 20));
            LocoList.add(new Loco("WAG-5", 119, 17));
            LocoList.add(new Loco("WAG-7", 123, 21));
            LocoList.add(new Loco("WAG-9", 123, 20));
            LocoList.add(new Loco("EMU", 0, 0));
            LocoList.add(new Loco("4KHP100", 123, 20));
            LocoList.add(new Loco("5KHP100", 123, 20));
            LocoList.add(new Loco("6KHP100", 123, 20));
        }

 public static List<Stock> StockList = new ArrayList<>();
        public static void PopulateStockList()
        {
            StockList.add(new Stock("COACH", "VNDB", 43, 48, 22));
            StockList.add(new Stock("COACH", "VNDB", 43, 48, 22));
            StockList.add(new Stock("COACH","LHB", 43, 48, 24));
            StockList.add(new Stock("COACH","ICF", 45, 50, 22));
            StockList.add(new Stock("COACH","HYBRID", 43, 48, 24));
            StockList.add(new Stock("WAGON", "EMU", 15, 20, 22));
            StockList.add(new Stock("WAGON","BCN", 20, 92, 15));
            StockList.add(new Stock("WAGON","BOXN", 20, 92, 10));
            StockList.add(new Stock("WAGON","CONTAINER", 5, 27, 12));


        }
    

    
}
