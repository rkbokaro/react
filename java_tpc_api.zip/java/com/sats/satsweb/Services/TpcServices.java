package com.sats.satsweb.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.sats.satsweb.Model.Curvature;
import com.sats.satsweb.Model.Gradient;
import com.sats.satsweb.Model.PsrInfra;
import com.sats.satsweb.Model.RollDiagram;
import com.sats.satsweb.Model.Route;
import com.sats.satsweb.Model.SimulationParameter;
import com.sats.satsweb.Repository.TpcRepository;

import ch.qos.logback.core.net.SyslogOutputStream;
//import javafx.scene.shape.Polyline;

import java.util.ArrayList;
import java.util.List;

//import javax.sql.DataSource;

@Service
public class TpcServices {

    @Autowired
    TpcRepository tpcRepository;

    public List<RollDiagram> RollDiagram(String routestring) {

        return tpcRepository.RollDiagram(routestring);

    }

    public List<Curvature> CurvatureInfra(String routestring) {

        return tpcRepository.CurvatureInfra(routestring);

    }

    public List<Gradient> GradientInfra(String routeString) {
        return tpcRepository.GradientInfra(routeString);

    }

    public List<PsrInfra> PsrInfra(String routeString) {
        return tpcRepository.PsrInfra(routeString);
    }

    List<Route> route;
    int unitDistanceInMeter = 1;

    public List<Route> PopulateTpcData(SimulationParameter simulationParameter) {

        List<RollDiagram> diagramData = tpcRepository.RollDiagram(simulationParameter.getRouteString());

        List<Gradient> gradientData = tpcRepository.GradientInfra(simulationParameter.getRouteString());

        List<Curvature> curvatureData = tpcRepository.CurvatureInfra(simulationParameter.getRouteString());

        List<PsrInfra> psrData = tpcRepository.PsrInfra(simulationParameter.getRouteString());

        double routedistance = diagramData.get(diagramData.size() - 1).getCumulativeDistance();

        List<Route> routelist = new ArrayList<>();

        System.out.println("size=" + diagramData.size());
        System.out.println("size=" + gradientData.size());
        System.out.println("size=" + curvatureData.size());
        System.out.println("size=" + psrData.size());

        diagramData.forEach(item -> {

            for (int index = (int) (item.getCumulativeDistance() * 1000); index < (item.getCumulativeDistance()
                    + item.getInterDistance()) * 1000; index++) {
                Route route1 = new Route();
                // System.out.println(item.getMaxspeed());

                if (item.getMaxspeed() != null) {
                    route1.setSectionSpeedP(item.getMaxspeed());
                }
                routelist.add(route1);
            }
        });

        gradientData.forEach(item -> {

            int start = (int) (Math.min(item.getGrade_SelectedRoute_FromKm(), item.getGrade_SelectedRoute_UptoKm())
                    * 1000);
            int end = (int) (Math.min(
                    Math.max(item.getGrade_SelectedRoute_FromKm(), item.getGrade_SelectedRoute_UptoKm()), routedistance)
                    * 1000);
            for (int index = start; index < end; index++) {
                routelist.get(index).setGradeValue(item.getGrade_Value());
            }
        });

        curvatureData.forEach(item -> {

            int start = (int) (Math.min(item.getCurve_SelectedRoute_FromKm(), item.getCurve_SelectedRoute_UptoKm())
                    * 1000);
            int end = (int) (Math.min(
                    Math.max(item.getCurve_SelectedRoute_FromKm(), item.getCurve_SelectedRoute_UptoKm()), routedistance)
                    * 1000);
            for (int index = start; index < end; index++) {
                routelist.get(index).setCurveAngle(item.getCurve_AngleInDegree());
            }
        });

        psrData.forEach(item -> {

            int start = (int) (Math.min(item.getPSR_SelectedRoute_FromKm(), item.getPSR_SelectedRoute_UptoKm()) * 1000);
            int end = (int) (Math.min(Math.max(item.getPSR_SelectedRoute_FromKm(), item.getPSR_SelectedRoute_UptoKm()),
                    routedistance) * 1000);
            for (int index = start; index < end; index++) {
                routelist.get(index).setPsrSpeedP(item.getPSR_PSpeedKmph());
            }
        });

        System.out.println(routelist.size());
        // System.out.println(routelist);
        this.route = routelist;
        return routelist;

    }

    public List<Route> simulateWithParameter(String locoType, int numberOfLoco, double adhesiveMass, String trailType,
        double trailingLoad, int trainLength) {
        double accelarationMPSS = 0.50;
        double accelarationKMPHPS = 0.50 * 3.6;
        double second = 0;
        double velocityKMPH = 0;
        double velocityMPS = 0;
        double nextVelocityMPS = 0;
        double targetSpeed = 0;
        double decelaration = 0.75 * numberOfLoco;

        if (locoType.equals("VNDB")) {
            decelaration = 0.75 * numberOfLoco;
        } else if (locoType.equals("EMU") || locoType.equals("MEMU")) {
            decelaration = 0.5 * numberOfLoco;
        } else if (locoType.equals("WAP7") || locoType.equals("WAP5")) {
            decelaration = 0.25 * numberOfLoco;
        } else {
            decelaration = 0.125;
        }

        boolean simulated = false;
       // Polyline velocityLine = new Polyline();

       // Polyline distanceLine = new Polyline();

       // Polyline distanceSpeedLine = new Polyline();

        String mode = "";
        String prevMode = "";
        int stoppage = 0;
        int coveredDistanceInMeter = 0;
        double coveredDistanceInKm = 0;
        int brakeStartPoint = route.size();
        int targetPoint = route.size();
        boolean speedRestrictionFlag = false;
        String prevPosition = "";

        int countACC = 0;
        int countDCC = 0;
        int countCoast = 0;
        int countStop = 0;
        int count = 0;

        boolean isCoasting = false;

        double totalDCCTimeInSec = 0;
        double totalACCTimeInSec = 0;
        double totalSTPGTimeInSec = 0;
        double totalCOASTTimeInSec = 0;
        double averageSpeedMPS = 0;
        double energyConsumedJule = 0;

        try {
            while (true) {
                speedRestrictionFlag = false;
                for (int i = coveredDistanceInMeter; i < Math.min(
                        coveredDistanceInMeter + Tpc.BrakingDistance(velocityMPS, "MPS", 0, "MPS", decelaration),
                        route.size()); i++) {
                    if (route.get(i).getEffectiveMaxSpeed() < (velocityMPS * 3.6) || route.get(i).getStoppageFlag()) {
                        if (route.get(i).getStoppageFlag()) {
                            brakeStartPoint = i - Tpc.BrakingDistance(velocityMPS, "MPS", 0, "KMPH", decelaration);
                            targetPoint = i;
                            targetSpeed = 0;
                        } else if (brakeStartPoint > i - Tpc.BrakingDistance(velocityMPS, "MPS",
                                route.get(i).getEffectiveMaxSpeed(), "KMPH", decelaration)) {
                            brakeStartPoint = i - Tpc.BrakingDistance(velocityMPS, "MPS",
                                    route.get(i).getEffectiveMaxSpeed(), "KMPH", decelaration);
                            targetPoint = i;
                            targetSpeed = route.get(i).getEffectiveMaxSpeed() / 3.6;
                        }
                    }
                }

                if (coveredDistanceInMeter >= brakeStartPoint - 1 && coveredDistanceInMeter < targetPoint) {
                    mode = "DCC";
                } else if (route.get(coveredDistanceInMeter).getStoppageFlag()
                        && stoppage <= route.get(coveredDistanceInMeter).getStoppageTime()) {
                    mode = "STOP";
                } else if (stoppage == route.get(coveredDistanceInMeter).getStoppageTime()
                        || coveredDistanceInMeter == 0) {
                    mode = "ACC";
                    brakeStartPoint = route.size();
                } else if (speedRestrictionFlag == false) {
                    mode = "ACC";
                } else if (speedRestrictionFlag == true) {
                    mode = "DCC";
                    brakeStartPoint = route.size();
                }

                if (!prevMode.isEmpty() && prevMode != mode) {
                    if (prevMode == "ACC")
                        countACC++;
                    if (prevMode == "DCC")
                        countDCC++;
                    if (prevMode == "STOP")
                        countStop++;
                }
                prevMode = mode;

                if (mode == "ACC") {
                    stoppage = 0;
                    // accelarationMPSS = (Tpc.TractiveEffort(velocityMPS, "MPS", locoType,
                    // numberOfLoco) - Tpc.ResistanceTrain(locoType, numberOfLoco, adhesiveMass,
                    // trailingLoad, trailType, velocityMPS, "MPS",
                    // route.get(coveredDistanceInMeter).getCurveAngle(),
                    // route.get(coveredDistanceInMeter).getGradeValue())) / (adhesiveMass *
                    // numberOfLoco + trailingLoad);
                    // NextVelocityMPS =
                    // Math.Min(route.get(coveredDistanceInMeter).getEffectiveMaxSpeed()/ 3.6,
                    // Math.Sqrt((velocityMPS * velocityMPS) + (2 * accelarationMPSS *
                    // unitDistanceInMeter)));

                    accelarationMPSS = (Tpc.TractiveEffort(velocityMPS, "MPS", locoType, numberOfLoco)
                            - Tpc.ResistanceTrain(locoType, numberOfLoco, adhesiveMass, trailingLoad, trailType,
                                    velocityMPS, "MPS", route.get(coveredDistanceInMeter).getCurveAngle(),
                                    route.get(coveredDistanceInMeter).getGradeValue()))
                            / (adhesiveMass * numberOfLoco + trailingLoad);
                    // accelarationMPSS = 0.50;
                    nextVelocityMPS = Math.min(route.get(coveredDistanceInMeter).getEffectiveMaxSpeed() / 3.6,
                            Math.sqrt((velocityMPS * velocityMPS) + (2 * accelarationMPSS * unitDistanceInMeter)));

                    if (accelarationMPSS <= 0) {

                    }

                    if (velocityMPS == route.get(coveredDistanceInMeter).getEffectiveMaxSpeed() / 3.6
                            && isCoasting == false) {
                        isCoasting = true;
                        countCoast++;
                    } else {
                        isCoasting = false;
                    }

                    if (accelarationMPSS > 0.0001) {
                        totalACCTimeInSec += ((2 * unitDistanceInMeter) / (velocityMPS + nextVelocityMPS));
                    } else {
                        totalCOASTTimeInSec += ((2 * unitDistanceInMeter) / (velocityMPS + nextVelocityMPS));
                    }

                    energyConsumedJule += Tpc.TractiveEffort(velocityMPS, "MPS", locoType, numberOfLoco)
                            * unitDistanceInMeter;

                    second = second + ((2 * unitDistanceInMeter) / (velocityMPS + nextVelocityMPS));
                    velocityMPS = nextVelocityMPS;
                    coveredDistanceInMeter += unitDistanceInMeter;
                }
                if (mode == "DCC") {
                    accelarationMPSS = (-1.0) * decelaration;
                    if (((velocityMPS * velocityMPS) + (2 * accelarationMPSS * unitDistanceInMeter)) > targetSpeed
                            * targetSpeed)// (TargetSpeed + 2 / (2 * TargetSpeed + Decelaration)) * (TargetSpeed + 2 /
                                          // (2 * TargetSpeed + Decelaration)))
                    {
                        nextVelocityMPS = Math
                                .sqrt((velocityMPS * velocityMPS) + (2 * accelarationMPSS * unitDistanceInMeter));
                    } else {
                        nextVelocityMPS = targetSpeed;
                    }
                    totalDCCTimeInSec += ((2 * unitDistanceInMeter) / (velocityMPS + nextVelocityMPS));
                    second = second + ((2 * unitDistanceInMeter) / (velocityMPS + nextVelocityMPS));
                    velocityMPS = nextVelocityMPS;
                    coveredDistanceInMeter += unitDistanceInMeter;
                }
                if (mode == "STOP" || coveredDistanceInMeter == route.size() - 1) {
                    accelarationMPSS = 0;
                    second = second + 1.0;

                    velocityMPS = 0;
                    coveredDistanceInMeter += 0;
                    stoppage++;
                }
                if (mode == "STOP") {
                    totalSTPGTimeInSec++;
                }
                averageSpeedMPS = coveredDistanceInMeter / second;

                accelarationKMPHPS = accelarationMPSS * 3.6;
                velocityKMPH = velocityMPS * 3.6;
                coveredDistanceInKm = (coveredDistanceInMeter) * 0.001;

                route.get(coveredDistanceInMeter).setSimulationDistance(coveredDistanceInMeter);
                route.get(coveredDistanceInMeter).setSimulationTime((int) second);
                route.get(coveredDistanceInMeter).setSimulationSpeed((int) velocityKMPH);

                if (velocityKMPH >= 125)
                    count++;

                if (coveredDistanceInMeter == route.size() - 1) {
                    return route;
                }
            }
        } catch (Exception ex) {
            throw ex;
        }
    }
}
