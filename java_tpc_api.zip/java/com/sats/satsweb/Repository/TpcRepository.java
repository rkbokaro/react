package com.sats.satsweb.Repository;

import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.sats.satsweb.Model.Curvature;
import com.sats.satsweb.Model.Gradient;
import com.sats.satsweb.Model.PsrInfra;
import com.sats.satsweb.Model.RollDiagram;

@Repository
public class TpcRepository {

    @Autowired
	private DataSource dataSource;
	//private JdbcTemplate jdbcTemplate;
	private SimpleJdbcCall simpleJdbcCall;


    public List<RollDiagram> RollDiagram(String routestring) {
		
			System.out.println("RollDiagram  in service " +  routestring);
		
		simpleJdbcCall = new SimpleJdbcCall(dataSource);
		
		simpleJdbcCall.withCatalogName("INFRA");
		
		
		simpleJdbcCall.withProcedureName("getRollDiagram");

		SqlParameterSource params = new MapSqlParameterSource();
		((MapSqlParameterSource) params).addValue("STTN_STR", routestring);

		simpleJdbcCall.returningResultSet("OUT_CURSOR", BeanPropertyRowMapper.newInstance(RollDiagram.class));

		Map<String, Object> ResultAns = simpleJdbcCall.execute(params);
	//	System.out.println("routestring in service " +  routestring);
	

		
		
		List<RollDiagram> dlist=(List) ResultAns.get("OUT_CURSOR");
		
		System.out.println("Result is1 : " + "result: "+dlist.size()  );
		//System.out.println("Result is2 : " + "result: "+dlist );
		

		return (List) ResultAns.get("OUT_CURSOR");

	}

	public List<Curvature> CurvatureInfra(String routestring) {
		
		simpleJdbcCall = new SimpleJdbcCall(dataSource);
		simpleJdbcCall.withCatalogName("INFRA");
		simpleJdbcCall.withProcedureName("GetCurvatureByRoute");
		
		
		System.out.println("CurvatureInfra  in service " +  routestring);

		SqlParameterSource params = new MapSqlParameterSource();
		((MapSqlParameterSource) params).addValue("ROUTESEQ", routestring);

		simpleJdbcCall.returningResultSet("OUT_CURSOR", BeanPropertyRowMapper.newInstance(Curvature.class));

		Map<String, Object> ResultAns = simpleJdbcCall.execute(params);
		System.out.println("CurvatureInfra  in service " +  routestring);
	
		

		
		
		List<Curvature> dlist=(List) ResultAns.get("OUT_CURSOR");
		
		System.out.println("PsrInfra is1 : " + "result: "+dlist.size()  );
		
		

		return (List) ResultAns.get("OUT_CURSOR");

	}

    public List<Gradient> GradientInfra(String routeString) {
        simpleJdbcCall= new SimpleJdbcCall(dataSource);
			simpleJdbcCall.withCatalogName("INFRA");
			simpleJdbcCall.withProcedureName("GetGradientByRoute");
			
			
			System.out.println("GradientInfra  in service " +  routeString);

			SqlParameterSource params = new MapSqlParameterSource();
			((MapSqlParameterSource) params).addValue("ROUTESEQ", routeString);

			simpleJdbcCall.returningResultSet("OUT_CURSOR", BeanPropertyRowMapper.newInstance(Gradient.class));

			Map<String, Object> ResultAns = simpleJdbcCall.execute(params);
			System.out.println("GradientInfra  in service " +  routeString);
		
			

			
			
			List<Gradient> dlist=(List) ResultAns.get("OUT_CURSOR");
			
			System.out.println("GradientInfra is1 : " + "result: "+dlist.size()  );
			
			

			return (List) ResultAns.get("OUT_CURSOR");

    }

    public List<PsrInfra> PsrInfra(String routeString) {
        simpleJdbcCall = new SimpleJdbcCall(dataSource);
		simpleJdbcCall.withCatalogName("INFRA");
		simpleJdbcCall.withProcedureName("getPSRByRoute");
		
		
		System.out.println("pPsrInfra  in service " +  routeString);

		SqlParameterSource params = new MapSqlParameterSource();
		((MapSqlParameterSource) params).addValue("ROUTESEQ", routeString);

		simpleJdbcCall.returningResultSet("OUT_CURSOR", BeanPropertyRowMapper.newInstance(PsrInfra.class));

		Map<String, Object> ResultAns = simpleJdbcCall.execute(params);
		System.out.println("ppPsrInfra  in service " +  routeString);
	
		

		
		
		List<PsrInfra> dlist=(List) ResultAns.get("OUT_CURSOR");
		
		
		System.out.println("PsrInfra is1 : " + "result: "+dlist.size());
		
		
	
		return (List) ResultAns.get("OUT_CURSOR");
    }
	
    


    
}
