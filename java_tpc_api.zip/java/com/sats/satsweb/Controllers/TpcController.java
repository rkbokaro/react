package com.sats.satsweb.Controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sats.satsweb.Model.Curvature;
import com.sats.satsweb.Model.Gradient;
import com.sats.satsweb.Model.PsrInfra;
import com.sats.satsweb.Model.RollDiagram;
import com.sats.satsweb.Model.Route;
import com.sats.satsweb.Model.SimulationParameter;
import com.sats.satsweb.Services.TpcServices;

import reactor.core.publisher.Flux;
import com.google.gson.Gson;

@CrossOrigin(origins = "*")

@RestController
public class TpcController {

	@Autowired
	TpcServices service;

	@GetMapping("/hello")
	public String hello() {
		return "Hello, world!";
	}

	@RequestMapping("/hello2")
	public String hello2() {
		return "Hello, world!22222222222222222";
	}

	@RequestMapping("/RollDiagram1/{RouteString}")
	public String RollDiagram1(@PathVariable String RouteString) {

		System.out.println(RouteString);
		return RouteString;
	}

	@GetMapping("/")
	public List<RollDiagram> hello1() {

		System.out.println("ccccccccccccccccccccccccccccccccccccc");

		List<RollDiagram> DetailsList = service.RollDiagram(
				"ANVT-SBB-GZB-CYZ-MIU-DER-BRKY-AJR-DKDE-FPMP-WAIR-CHL-GNRL-SKQ-KRJ-KAMP-DAR-SOM-KLA-MWUE-ALJN-DAQ-MXK-SNS-HRS-PORA-JLS-CMR-BRN");
		return DetailsList;
	}

	// @RequestMapping(path = "/RollDiagram", method = RequestMethod.GET)
	// public List<RollDiagram_Tb> RollDiagram(@RequestParam("RouteString") String
	// RouteString,HttpServletRequest request)
	@RequestMapping("/RollDiagramInfra/{routeString}")
	public Flux<RollDiagram> RollDiagram(@PathVariable String routeString) throws InterruptedException {

		System.out.println("Fetching RollDiagram Data for : ");
		List<RollDiagram> DetailsList = service.RollDiagram(routeString);

		for (RollDiagram item : DetailsList) {
			item.ProcessData();

		}

		return Flux.fromIterable(DetailsList);
	}

	@RequestMapping("/CurvatureInfra/{routeString}")
	public List<Curvature> CurvatureInfra(@PathVariable String routeString) throws InterruptedException {

		List<Curvature> DetailsList = service.CurvatureInfra(routeString);
		return DetailsList;

	}

	@RequestMapping("/GradientInfra/{routeString}")
	public List<Gradient> GradientInfra(@PathVariable String routeString) throws InterruptedException {
		List<Gradient> DetailsList = service.GradientInfra(routeString);
		return DetailsList;

	}

	@RequestMapping("/PsrInfra/{routeString}")
	public List<PsrInfra> PsrInfra(@PathVariable String routeString) throws InterruptedException {
		List<PsrInfra> DetailsList = service.PsrInfra(routeString);
		return DetailsList;

	}


	@RequestMapping("/SimulatedTrainData/{simulationParameter}")
	public List<Route> SimulatedTrainData(@PathVariable String routeString) throws InterruptedException {
	  
      
		// System.out.println(routeString);
		// SimulationParameter simulationParameter= new SimulationParameter();

		// simulationParameter.setLocoType("WAP5");
		// simulationParameter.setLocoCount(1);
		// simulationParameter.setStockType("LHB");
		// simulationParameter.setStockcount(20);
		// simulationParameter.setStockUnitWeight(97.6);
		// simulationParameter.setStockUnitLength(26.75);
		// simulationParameter.setTrailWeight(976);
		// simulationParameter.setTrailLength(535);
		// simulationParameter.setLocoUnitWeight(78);
		// simulationParameter.setLocoUnitLength(36);
		// simulationParameter.setLocoWeight(36);
		// simulationParameter.setLocoLength(78);
		// simulationParameter.setTotalWeight(1054);
		// simulationParameter.setTotalLength(571);
		// simulationParameter.setRouteString("DBRG-CKW-LHL-DKM-CHB-PNT-NTSK-TSK-SPGN-CGF-BDT-DJG-NHK-BTZ-NAM-BFD");

		

		// List<Route> DetailsList=	service.PopulateTpcData(simulationParameter);
	    // return DetailsList;
		
		return null;
	}


	@RequestMapping("/PsrInfra1/{routeString}")
	public List<Route>  PsrInfra1(@PathVariable String routeString) throws InterruptedException {
		//List<PsrInfra> DetailsList = service.PsrInfra(routeString);
		//return DetailsList;

		 SimulationParameter simulationParameter= new SimulationParameter();

		 simulationParameter.setLocoType("WAP5");
		 simulationParameter.setLocoCount(1);
		 simulationParameter.setStockType("LHB");
		 simulationParameter.setStockcount(20);
		 simulationParameter.setStockUnitWeight(97.6);
		 simulationParameter.setStockUnitLength(26.75);
		 simulationParameter.setTrailWeight(976);
		 simulationParameter.setTrailLength(535);
		 simulationParameter.setLocoUnitWeight(78);
		 simulationParameter.setLocoUnitLength(36);
		 simulationParameter.setLocoWeight(36);
		 simulationParameter.setLocoLength(78);
		 simulationParameter.setTotalWeight(1054);
		 simulationParameter.setTotalLength(571);
		 simulationParameter.setRouteString("DBRG-CKW-LHL-DKM-CHB-PNT-NTSK-TSK-SPGN-CGF-BDT-DJG-NHK-BTZ-NAM-BFD");
		 List<Route> DetailsList1=	service.PopulateTpcData(simulationParameter);

//	Gson gson = new Gson();
	//String jsonString = gson.toJson(simulationParameter);
	//	 System.out.println(jsonString);

		return DetailsList1;

	}


}
