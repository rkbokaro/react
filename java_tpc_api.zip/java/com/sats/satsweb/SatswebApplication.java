package com.sats.satsweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SatswebApplication {

	public static void main(String[] args) {
		SpringApplication.run(SatswebApplication.class, args);
		System.out.println("hi");
	}

}
