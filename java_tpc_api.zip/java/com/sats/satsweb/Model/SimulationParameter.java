package com.sats.satsweb.Model;

import lombok.Data;

@Data
public class SimulationParameter {
    private String locoType;
    private int locoCount;
    private String stockType;
    private int stockcount;
    private double stockUnitWeight;
    private double stockUnitLength;
    private double trailWeight;
    private double trailLength;
    private double locoUnitWeight;
    private double locoUnitLength;
    private double locoWeight;
    private double locoLength;
    private double totalWeight;
    private double totalLength;
    private String routeString;  

}
