package com.sats.satsweb.Model;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


import lombok.Data;


@Data
public class RollDiagram {
	


	
	
	private  int stationSeq, blockSectionLineCount, stationLineCount, platformCount, stationAdjacencyCount, allConnectionCount, nextConnectionCount, prevConnectionCount;
	private  String	stationCode , stationName,stationClass,blockSection,stationAdjacency,stationLines,stationPlatforms,blockSectionLines, allConnections, nextConnections, prevConnections,REFSTTN,MILEPOSTKM,MILEPOSTSUBKM;	
	private  Double	cumulativeDistance, stationMilePost, prevStationDistance, nextStationDistance,  interDistance, maxspeed ;	
	
	public List<Platform> platformList = new ArrayList<Platform>();
	public List<StationLine> stationLineList = new ArrayList<StationLine>();	
	public List<StationAdjacency> stationAdjacencyList = new ArrayList<StationAdjacency>();
	public List<LineConnection> allConnectionList = new ArrayList<LineConnection>();
	public List<LineConnection> nextConnectionList = new ArrayList<LineConnection>();
	public List<LineConnection> prevConnectionList = new ArrayList<LineConnection>();
	
	public List<BlockSectionLine> blockSectionLineList = new ArrayList<BlockSectionLine>();
	
	public void ProcessData()
	{
		List<String> BlockSectionLineStringList=new ArrayList<String>();  			
		if(!(blockSectionLines==null) && !blockSectionLines.isEmpty() && !blockSectionLines.isEmpty())
		{
			BlockSectionLineStringList =  Arrays.asList(blockSectionLines.split("#"));
			for(String item: BlockSectionLineStringList)
			{
				BlockSectionLine pf = new BlockSectionLine(item);
				blockSectionLineList.add(pf);
			}
			blockSectionLineCount=blockSectionLineList.size();
		}	
		
		List<String> StationLineStringList=new ArrayList<String>();  			
		if(!(stationLines==null) && !stationLines.isEmpty() && !stationLines.isEmpty())
		{
			StationLineStringList =  Arrays.asList(stationLines.split("#"));
			for(String item: StationLineStringList)
			{
				StationLine pf = new StationLine(item);
				stationLineList.add(pf);
			}
			stationLineCount=stationLineList.size();
		}
		
		List<String> PlatformStringList=new ArrayList<String>();  		
			if(!(stationPlatforms==null) && !stationPlatforms.isEmpty() && !stationPlatforms.isEmpty())
			{
				PlatformStringList =  Arrays.asList(stationPlatforms.split("#"));
				for(String item: PlatformStringList)
				{
					Platform pf = new Platform(item);
					platformList.add(pf);
				}
				
				
				platformCount=platformList.size();
			}
			
			List<String> StationAdjacencyStringList=new ArrayList<String>();  			
			if(!(stationAdjacency==null) && !stationAdjacency.isEmpty() && !stationAdjacency.isEmpty())
			{
				StationAdjacencyStringList =  Arrays.asList(stationAdjacency.split("#"));
				for(String item: StationAdjacencyStringList)
				{
					StationAdjacency pf = new StationAdjacency(item);
					stationAdjacencyList.add(pf);
				}
				stationAdjacencyCount=stationAdjacencyList.size();
			}
			
			List<String> AllConnectionStringList=new ArrayList<String>();  			
			if(!(allConnections==null) && !allConnections.isEmpty() && !allConnections.isEmpty())
			{
				AllConnectionStringList =  Arrays.asList(allConnections.split("#"));
				for(String item: AllConnectionStringList)
				{
					LineConnection cn = new LineConnection(item);
					allConnectionList.add(cn);
				}
				allConnectionCount = allConnectionList.size();
			}
			
			
			List<String> NextConnectionStringList=new ArrayList<String>();  			
			if(!(nextConnections==null) && !nextConnections.isEmpty() && !nextConnections.isEmpty())
			{
				NextConnectionStringList =  Arrays.asList(nextConnections.split("#"));
				for(String item: NextConnectionStringList)
				{
					LineConnection cn = new LineConnection(item);
					nextConnectionList.add(cn);
				}
				nextConnectionCount = nextConnectionList.size();
			}
			
			List<String> PrevConnectionStringList=new ArrayList<String>();  			
			if(!(prevConnections==null) && !prevConnections.isEmpty() && !prevConnections.isEmpty())
			{
				PrevConnectionStringList =  Arrays.asList(prevConnections.split("#"));
				for(String item: PrevConnectionStringList)
				{
					LineConnection cn = new LineConnection(item);
					prevConnectionList.add(cn);
				}
				prevConnectionCount = prevConnectionList.size();
			}
	}
}






