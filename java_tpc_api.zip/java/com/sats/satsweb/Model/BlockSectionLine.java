package com.sats.satsweb.Model;

import lombok.Data;

@Data
public class BlockSectionLine {
	
	String lineSeq,lineName,length,gauge,traction,numbofLevelCrossing,numbOfSignals,sysOfWorking;
	
	BlockSectionLine (String str)
	{

			String[] BlckLineAttributes =  str.split(":");
			lineSeq=BlckLineAttributes[0];
			lineName=BlckLineAttributes[1];
			length=BlckLineAttributes[2];
			gauge=BlckLineAttributes[3];	
			traction=BlckLineAttributes[4];
			numbofLevelCrossing=BlckLineAttributes[5];
			numbOfSignals=BlckLineAttributes[6];	
			sysOfWorking=BlckLineAttributes[7];
	
	}

}
