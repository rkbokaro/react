package com.sats.satsweb.Model;

import lombok.Data;

@Data
public class Route {
    private String routecode = "";
    private String location ="";
    private Boolean stoppageFlag = true;
    private int stoppageTime =0;
    private Double sectionSpeedP =0.0;
    private int sectionSpeedG =0;
    private int gradeValue=0;
    private Double curveAngle=0.0;
    private int curveSide=0;    
    private int curveRadius=0;
    private Double psrSpeedP=0.0;
    private int psrSpeedG=0;
    private int maxSpeedP=0;
    private int maxSpeedG=0;
    private int effectiveMaxSpeed=0;   
    private int milePost=0;
    private String position="";
    private String speedRestrictionType="P";
    private int simulationTime=0;
    private int simulationDistance=0;
    private int simulationSpeed=0;

}

