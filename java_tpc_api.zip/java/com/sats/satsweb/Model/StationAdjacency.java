package com.sats.satsweb.Model;
import lombok.Data;

@Data
public class StationAdjacency {
	
	String stationCode,hPosition,vPosition,numbOfBlockLines;
	
	StationAdjacency(String str)
	{
		String[] AdjacencyAttributes =  str.split(":");
		stationCode=AdjacencyAttributes[0];
		hPosition=AdjacencyAttributes[1];
		vPosition=AdjacencyAttributes[2];
		numbOfBlockLines=AdjacencyAttributes[3];		
	}	
	
	

}
