package com.sats.satsweb.Model;

public class SimulationResult {
    
    
}
