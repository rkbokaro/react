package com.sats.satsweb.Model;

import lombok.Data;

@Data
public class Gradient {

	String seqnumber;
	String sttncode;
	String coablcksctn;
	Double distance;
	Double cum_DISTANCE;
	String grade_RefMilePost_FromRefStation;
	String grade_RefMilePost_FromKm;
	String grade_RefMilePost_FromSubKm;
	String grade_RefMilePost_UptoKm;
	String grade_RefMilePost_UptoSubKm;
	Double Grade_SelectedRoute_FromKm;
	Double Grade_SelectedRoute_UptoKm;
	String grade_LengthAsGiven;
	Double grade_Calculated_Length;
	String grade_Type;
	Integer grade_Value;
	String gradientvalue;
	String grade_PTimeLoss;
	String grade_GTimeLoss;
	String grade_Remark;

	public String getSeqnumber() {
		return seqnumber;
	}

	public void setSeqnumber(String seqnumber) {
		this.seqnumber = seqnumber;
	}

	public String getSttncode() {
		return sttncode;
	}

	public void setSttncode(String sttncode) {
		this.sttncode = sttncode;
	}

	public String getCoablcksctn() {
		return coablcksctn;
	}

	public void setCoablcksctn(String coablcksctn) {
		this.coablcksctn = coablcksctn;
	}

	public Double getDistance() {
		return distance;
	}

	public void setDistance(Double distance) {
		this.distance = distance;
	}

	public Double getCum_DISTANCE() {
		return cum_DISTANCE;
	}

	public void setCum_DISTANCE(Double cum_DISTANCE) {
		this.cum_DISTANCE = cum_DISTANCE;
	}

	public String getGrade_RefMilePost_FromRefStation() {
		return grade_RefMilePost_FromRefStation;
	}

	public void setGrade_RefMilePost_FromRefStation(String grade_RefMilePost_FromRefStation) {
		this.grade_RefMilePost_FromRefStation = grade_RefMilePost_FromRefStation;
	}

	public String getGrade_RefMilePost_FromKm() {
		return grade_RefMilePost_FromKm;
	}

	public void setGrade_RefMilePost_FromKm(String grade_RefMilePost_FromKm) {
		this.grade_RefMilePost_FromKm = grade_RefMilePost_FromKm;
	}

	public String getGrade_RefMilePost_FromSubKm() {
		return grade_RefMilePost_FromSubKm;
	}

	public void setGrade_RefMilePost_FromSubKm(String grade_RefMilePost_FromSubKm) {
		this.grade_RefMilePost_FromSubKm = grade_RefMilePost_FromSubKm;
	}

	public String getGrade_RefMilePost_UptoKm() {
		return grade_RefMilePost_UptoKm;
	}

	public void setGrade_RefMilePost_UptoKm(String grade_RefMilePost_UptoKm) {
		this.grade_RefMilePost_UptoKm = grade_RefMilePost_UptoKm;
	}

	public String getGrade_RefMilePost_UptoSubKm() {
		return grade_RefMilePost_UptoSubKm;
	}

	public void setGrade_RefMilePost_UptoSubKm(String grade_RefMilePost_UptoSubKm) {
		this.grade_RefMilePost_UptoSubKm = grade_RefMilePost_UptoSubKm;
	}

	public String getGrade_LengthAsGiven() {
		return grade_LengthAsGiven;
	}

	public void setGrade_LengthAsGiven(String grade_LengthAsGiven) {
		this.grade_LengthAsGiven = grade_LengthAsGiven;
	}

	public Double getGrade_Calculated_Length() {
		return grade_Calculated_Length;
	}

	public void setGrade_Calculated_Length(Double grade_Calculated_Length) {
		this.grade_Calculated_Length = grade_Calculated_Length;
	}

	public String getGrade_Type() {
		return grade_Type;
	}

	public void setGrade_Type(String grade_Type) {
		this.grade_Type = grade_Type;
	}

	
	public String getGradientvalue() {
		return gradientvalue;
	}

	public void setGradientvalue(String gradientvalue) {
		this.gradientvalue = gradientvalue;
	}

	public String getGrade_PTimeLoss() {
		return grade_PTimeLoss;
	}

	public void setGrade_PTimeLoss(String grade_PTimeLoss) {
		this.grade_PTimeLoss = grade_PTimeLoss;
	}

	public String getGrade_GTimeLoss() {
		return grade_GTimeLoss;
	}

	public void setGrade_GTimeLoss(String grade_GTimeLoss) {
		this.grade_GTimeLoss = grade_GTimeLoss;
	}

	public String getGrade_Remark() {
		return grade_Remark;
	}

	public void setGrade_Remark(String grade_Remark) {
		this.grade_Remark = grade_Remark;
	}

}
