package com.sats.satsweb.Model;

public class Loco {


     public String LocoType;
        public double Weight;
        public double Length;

        public Loco() 
        {
        
        }
        public Loco(String loco, double weight, double length )
        {
            LocoType = loco;
            Weight = weight;
            Length = length;
        }        
    }


