package com.sats.satsweb.Model;import lombok.Data;

@Data
public class StationLine {
	
	
	 int lineSeq,numbOfTrainsAllowed;
	 String lineName,traction,gauge;
	 double length,csr;
	
	StationLine (String str)
	{

			String[] SttnLineAttributes =  str.split(":");
			lineSeq=Integer.parseInt(SttnLineAttributes[0]);
			lineName=SttnLineAttributes[1];
			traction=SttnLineAttributes[2];
			length=Double.parseDouble(SttnLineAttributes[3]);	
			csr=Double.parseDouble(SttnLineAttributes[4]);
			gauge=SttnLineAttributes[5];
			numbOfTrainsAllowed=Integer.parseInt(SttnLineAttributes[6]);		
	
	}

}