package com.sats.satsweb.Model;

import lombok.Data;

@Data
public class Curvature {
	
	int     SEQNUMBER;
	String  STTNCODE;
	String  COABLCKSCTN;  
	Double  distance;
	Double  CUM_DISTANCE ;          
	String  Curve_RefMilePost_FromRefStation;
	Double  Curve_RefMilePost_FromKm;
	String  Curve_RefMilePost_FromSubKm;

	String  Curve_RefMilePost_UptoKm;
	 
	String  Curve_RefMilePost_UptoSubKm;
	Double  Curve_SelectedRoute_FromKm;
	Double  Curve_SelectedRoute_UptoKm;
	Double  Curve_LengthAsGiven;
	Double  Curve_Calculated_Length;
	Double  Curve_RadiusInMeter;
	Double  Curve_AngleInDegree;
	Double  Curve_PTimeLoss;
	Double  Curve_GTimeLoss;
	String  Curve_Remark;

	
	
	

}
