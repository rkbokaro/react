package com.sats.satsweb.Model;
import lombok.Data;

@Data
public class Platform
{

	String pfname, lineNumber, verticalposition, horizontalposition;
	Platform(String str)
	{
		String[] PFAttributes =  str.split(":");
		pfname=PFAttributes[0];
		lineNumber=PFAttributes[1];
		verticalposition=PFAttributes[2];
		horizontalposition=PFAttributes[3];		
	}	
}

