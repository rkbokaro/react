package com.sats.satsweb.Model;
import lombok.Data;

@Data
public class PsrInfra {
	int    SEQNUMBER;
    String STTNCODE;
    String COABLCKSCTN; 
    Double distance;
    Double CUM_DISTANCE; 
    String station_milepost_I;
    String station_milepost_II;
    String station_milepost_III;
    Double PSR_RefMilePost_FromKm;
    Double PSR_RefMilePost_FromSubKm;
    Double PSR_RefMilePost_UptoKm;
    Double PSR_RefMilePost_UptoSubKm;
    Double PSR_SelectedRoute_FromKm;
    Double PSR_SelectedRoute_UptoKm;
    Double PSR_LengthAsGiven;    
    Double PSR_Calculated_Length;
    Double PSR_PSpeedKmph;
    Double PSR_GSpeedKmph;
    String PSR_PTimeLoss;
    String PSR_GTimeLoss;
    String PSR_PermanentTemporaryFlag;
    String PSR_StopDeadFlag;
    String PSR_ValidFromDate;
    String PSR_ValidUptoDate;
    String PSR_ApplicableFromTime;
    String PSR_ApplicableUptoTime;
    String sctnspeed;
    
    
    
}
