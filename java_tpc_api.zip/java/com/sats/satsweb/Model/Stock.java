package com.sats.satsweb.Model;

public class Stock {

      public String StockType;
        public double EmptyWeight;
        public double LoadedWeight;
        public double Length;
        public String TrailType;

        public Stock() 
        {
        
        }

        public Stock(String trailType, String stockType, double emptyWeight, double loadedWeight, double length)
        {
            TrailType = trailType;
            StockType=stockType;
            EmptyWeight=emptyWeight;
            LoadedWeight=loadedWeight;
            Length=length;
        }

}
