package com.sats.satsweb.Model;

import lombok.Data;

@Data
public class LineConnection {
	
	
	
	String stationLine, blockSection, blockSectionLine, sendrecieveFlag;
	LineConnection(String str)
	{
		String[] ConnectionAttributes =  str.split(":");
		stationLine=ConnectionAttributes[0];
		blockSection=ConnectionAttributes[1];
		blockSectionLine=ConnectionAttributes[2];
		sendrecieveFlag=ConnectionAttributes[3];		
	}	

}